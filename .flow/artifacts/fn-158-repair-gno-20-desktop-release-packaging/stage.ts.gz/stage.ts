import {stageRuntime} from "/home/gordon/work/gno/desktop/electrobun-shell/scripts/stage-gno-runtime.ts";
await stageRuntime("/home/gordon/work/gno","/home/gordon/.cache/agent-tmp/desktop-bun-recovery/gno-runtime");
