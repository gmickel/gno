# Desktop Bun staging recovery

Release macOS failure: Electrobun1.16.0 preBuild executes its1.3.9 core Bun; root bun.lock v2 requires the newer runtime. build.bunVersion is evaluated after preBuild and alone cannot fix staging.

Changed only electrobun.config.ts, scripts/stage-gno-runtime.ts, scripts/verify-packaged-runtime.ts and scripts/stage-gno-runtime.test.ts. Root development Bun pin drives both staging and the bundled launcher runtime. Staging checks actual binary version before replacing staging output. Packaged verification checks shipped Bun version before CLI tests. No npm package source, workflow, tag or Git change.

Actual Linux reproduction uses registry-integrity-verified Bun1.3.9 (old-bun-origin.json) to run the new staging hook: stage.log records Bun1.4.2 production frozen-lock install,540 packages,exit0. The resulting isolated runtime executed version/init/update/search with Bun1.4.2, all exit0 and actual Cobalt result; cli-proof.json and raw stdout/stderr retained. This proves staging and runtime loading, not a signed macOS app or Windows executable.

Focused desktop tests10pass34assertions. Four owned files type-aware/typecheck lint zero warnings/errors. Format applied. No full core suite repeated.

Electrobun1.16 src/cli/index.ts1823 hardcodes currentTarget to hostOS/ARCH. Current build does not expose a Windows cross-target path onLinux; use Windows runner. Bundled override downloads target Bun from official release assets; existing signing/entitlements path remains unchanged. Host owns local macOS signing/build and release assets from the follow-up packaging commit, preserving original2.0 tag.
