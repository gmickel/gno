import json,pathlib,hashlib,copy
root=pathlib.Path(__file__).resolve().parent
fixture=json.loads((root/"fixture.json").read_text())
data={}
for mode in ["sized","auto"]:
 d=root/mode
 events=[json.loads(x) for x in (d/"child.jsonl").read_text().splitlines()]
 res=json.loads((d/"result.json").read_text());receipt=json.loads((d/"process-receipt.json").read_text())
 model=[x for x in events if x["kind"]=="model-loaded"];contexts=[x for x in events if x["kind"]=="context-created"];scores=[x for x in events if x["kind"]=="score-end"];tokens=[x for x in events if x["kind"]=="formatted-input"];options=[x for x in events if x["kind"]=="ranking-options"]
 assert len(model)==len(contexts)==len(options)==1
 assert len(scores)==2 and len(tokens)==12
 assert receipt["exitCode"]==0 and receipt["stopReason"] is None and receipt["allOwnedAbsent"]
 assert all(row["result"]["ok"] and len(row["result"]["value"])==6 for row in res["rows"])
 c=contexts[0];m=model[0]
 assert m["backend"]=="cuda" and m["nativeVersion"]=="3.19.1" and m["gpuLayers"]==29
 assert c["contextSize"]==({"sized":768,"auto":40960}[mode])
 for key in ["cpuRam","gpuVram"]:
  assert c["aggregate"][key]-c["before"][key]==c["nativeBytes"][key]
  assert c["before"][key]==m["modelBytes"][key]
 for event in scores:
  assert event["arguments"]==fixture["input"]
  assert event["contexts"]==[{"contextSize":c["contextSize"],"nativeBytes":c["nativeBytes"]}]
 disposed=[x for x in events if x["kind"]=="context-disposed"]
 assert len(disposed)==1 and disposed[0]["aggregate"]==m["aggregate"]
 requests=[x for x in events if x["kind"]=="request-start" and x["value"]["op"]=="rerank"]
 assert len(requests)==2
 assert all(x["value"]["query"]==fixture["input"][0] and x["value"]["documents"]==fixture["input"][1] for x in requests)
 resources=[json.loads(x) for x in (d/"resources.jsonl").read_text().splitlines()]
 child=next(x["pid"] for x in events if x["kind"]=="child-birth")
 parent=next(x["ppid"] for x in events if x["kind"]=="child-birth")
 assert child!=parent and all(p["pid"]!=parent for row in resources for p in row["gpuProcesses"])
 assert any(p["pid"]==child for row in resources for p in row["gpuProcesses"])
 assert all({p["pid"]:p["mib"] for p in row["gpuProcesses"] if p["pid"] in [1475083,4007014]}=={1475083:925,4007014:428} for row in resources)
 binaries=sorted({p for row in resources for proc in row["owned"] for p in proc.get("nativeMaps",[])})
 data[mode]={"events":events,"result":res,"receipt":receipt,"model":m,"context":c,"scores":scores,"tokens":tokens,"options":options[0],"peakRssMiB":max(x["ownedRssKiB"] for x in resources)/1024,"peakGpuMiB":max(x["ownedGpuMiB"] for x in resources),"childPid":child,"parentPid":parent,"nativeMappedFiles":{p:hashlib.file_digest(open(p,"rb"),"sha256").hexdigest() for p in binaries}}
a=data["sized"];b=data["auto"]
assert a["model"]["modelBytes"]==b["model"]["modelBytes"]
for key in ["batchSize","currentThreads","idealThreads","flashAttention","kvCacheKeyType","kvCacheValueType"]:assert a["context"][key]==b["context"][key]
assert a["options"]["original"]==b["options"]["original"]
original=copy.deepcopy(b["options"]["original"]);del original[0]["contextSize"]
assert b["options"]["effective"]==original and a["options"]["effective"]==a["options"]["original"]
nativeA=[x["result"] for x in a["scores"]];nativeB=[x["result"] for x in b["scores"]]
publicA=[x["result"] for x in a["result"]["rows"]];publicB=[x["result"] for x in b["result"]["rows"]]
stream=lambda d:[{k:x[k] for k in ["query","document","tokens"]} for x in d["tokens"]]
assert nativeA==nativeB and nativeA[0]==nativeA[1]
assert publicA==publicB and publicA[0]==publicA[1]
assert stream(a)==stream(b) and stream(a)[:6]==stream(a)[6:]
changed=copy.deepcopy(publicB);changed[0]["value"][0]["score"]+=0.000001
assert changed!=publicA
changedTokens=copy.deepcopy(stream(b));changedTokens[0]["tokens"].pop()
assert changedTokens!=stream(a)
summary={"stratum":"final-runtime-native-allocation-cuda-v1","passed":True,"arms":{},"parity":{"fullPreparedInputs":True,"fullNativeFormattedTokens":True,"unroundedNativeScores":True,"publicScoresRanksIndices":True,"coldWarmWithinArm":True,"modelNativeAllocationEqual":True,"resolvedOtherSettingsEqual":True,"onlyContextSizeOverrideRemoved":True,"aggregateMatchesDirectNativeCounter":True,"nativeCountersStableAfterColdWarm":True,"disposedReturnsToModelOnly":True,"mutatedScoreRejected":True,"truncatedTokenStreamRejected":True},"allocationSavedBytes":{k:b["context"]["nativeBytes"][k]-a["context"]["nativeBytes"][k] for k in ["cpuRam","gpuVram"]},"limitations":["One ordered pair sized then auto; not throughput/p99 or unbiased performance estimate","Whole calls include observation overhead and warm filesystem/cuda caches; no cache reset","Native-reported context+compute buffers exclude model/runtime/driver extras","No Metal extrapolation; oldpressure failures untouched","Freshfinalruntime sizingpolicy control; not unchanged270c product baseline"]}
for mode,d in data.items():
 summary["arms"][mode]={"contextSize":d["context"]["contextSize"],"nativeBytes":d["context"]["nativeBytes"],"modelBytes":d["model"]["modelBytes"],"aggregate":d["context"]["aggregate"],"contextCreationMs":d["context"]["durationMs"],"scoreMs":[x["durationMs"] for x in d["scores"]],"wholeCallMs":[x["end"]-x["start"] for x in d["result"]["rows"]],"wholeProcessMs":d["receipt"]["wallMs"],"peakRssMiB":d["peakRssMiB"],"peakGpuMiB":d["peakGpuMiB"],"childPid":d["childPid"],"parentPid":d["parentPid"],"allOwnedAbsent":d["receipt"]["allOwnedAbsent"],"nativeMappedFiles":d["nativeMappedFiles"],"resolvedSettings":{k:d["context"][k] for k in ["batchSize","currentThreads","idealThreads","flashAttention","kvCacheKeyType","kvCacheValueType"]},"slowerThanOtherArm":mode=="sized"}
(root/"analysis.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
