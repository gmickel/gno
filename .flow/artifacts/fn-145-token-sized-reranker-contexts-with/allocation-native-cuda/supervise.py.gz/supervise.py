import json,os,pathlib,subprocess,signal,time,sys,hashlib
root=pathlib.Path(__file__).resolve().parent
mode=sys.argv[1]
if mode not in ["sized","auto"]:raise RuntimeError("Unknown arm")
out=root/mode
out.mkdir(mode=0o700)
source=json.loads((root/"package-pins.json").read_text())["sourceRoot"]
plan={"mode":mode,"sourceRoot":source,"fixture":str(root/"fixture.json"),"output":str(out/"result.json"),"childLog":str(out/"child.jsonl")}
(out/"plan.json").write_text(json.dumps(plan,indent=2))
def gpu():
 p=subprocess.run(["nvidia-smi","--query-gpu=memory.total,memory.used,memory.free","--format=csv,noheader,nounits"],capture_output=True,text=True,check=True)
 return [int(v.strip()) for v in p.stdout.strip().split(",")]
def gpu_processes():
 p=subprocess.run(["nvidia-smi","--query-compute-apps=pid,used_memory","--format=csv,noheader,nounits"],capture_output=True,text=True,check=True)
 return [{"pid":int(line.split(",")[0]),"mib":int(line.split(",")[1])} for line in p.stdout.splitlines()]
def processes():
 result={}
 for p in pathlib.Path("/proc").iterdir():
  if not p.name.isdigit():continue
  try:
   tail=(p/"stat").read_text().rsplit(")",1)[1].split()
   status=(p/"status").read_text()
   rss=next((int(v.split()[1]) for v in status.splitlines() if v.startswith("VmRSS:")),0)
   result[int(p.name)]={"pid":int(p.name),"ppid":int(tail[1]),"pgid":int(tail[2]),"startTicks":tail[19],"rssKiB":rss}
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return result
def headroom():
 mem={line.split(":")[0]:int(line.split()[1]) for line in pathlib.Path("/proc/meminfo").read_text().splitlines() if line.startswith(("MemAvailable:","MemTotal:"))}
 return {"time":time.time(),"gpuMiB":gpu(),"gpuProcesses":gpu_processes(),"memoryKiB":mem}
if mode=="auto":
 previous=json.loads((root/"sized/process-receipt.json").read_text())
 if previous["exitCode"]!=0 or previous["stopReason"] or not previous["allOwnedAbsent"]:raise RuntimeError("Prior arm did not finish safely")
 current=processes()
 if any(p["pid"] in current and current[p["pid"]]["startTicks"]==p["startTicks"] for p in previous["observed"]):raise RuntimeError("Previous owner still present")
checks=[headroom()];time.sleep(1);checks.append(headroom())
(out/"headroom.json").write_text(json.dumps(checks,indent=2))
if any(x["gpuMiB"][2]<12288 or x["memoryKiB"]["MemAvailable"]<12*1024*1024 for x in checks):raise RuntimeError("Conservative 8GiB workload+4GiB reserve not admitted")
if any({p["pid"] for p in x["gpuProcesses"]}!={1475083,4007014} for x in checks):raise RuntimeError("Unexpected GPU owner: no inference admitted")
env={k:os.environ[k] for k in ["PATH","USER","SHELL"] if k in os.environ}
isolation=out/"isolation";isolation.mkdir()
env.update(HOME=str(isolation/"home"),XDG_CONFIG_HOME=str(isolation/"config"),XDG_DATA_HOME=str(isolation/"data"),XDG_STATE_HOME=str(isolation/"state"),XDG_CACHE_HOME=str(isolation/"cache"),TMPDIR=str(isolation),GNO_OFFLINE="1",GNO_ALLOW_DOWNLOAD="0",GNO_LLAMA_GPU="cuda",GNO_LLAMA_BUILD="never",CUDA_PATH="/opt/cuda")
command=["bun","--no-env-file",str(root/"run.ts"),str(out/"plan.json"),"--native"]
start=time.monotonic();observed={};samples=[];stop=None
with (out/"stdout.log").open("w") as stdout,(out/"stderr.log").open("w") as stderr:
 p=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 while p.poll() is None:
  table=processes();ids={p.pid}
  for _ in range(8):
   ids|={pid for pid,v in table.items() if v["ppid"] in ids or v["pgid"]==p.pid}
  if ids & {1475083,4007014}:raise RuntimeError("Protected user PID ownership conflict")
  owned=[v for pid,v in table.items() if pid in ids];vram=gpu_processes()
  for v in owned:
   if True:
    try:v["nativeMaps"]=sorted({line.split()[-1] for line in pathlib.Path("/proc",str(v["pid"]),"maps").read_text().splitlines() if ".node" in line or "libcuda." in line})
    except FileNotFoundError:v["nativeMaps"]=[]
   observed[v["pid"]]=v
  total=sum(v["rssKiB"] for v in owned);used=sum(v["mib"] for v in vram if v["pid"] in ids)
  elapsed=time.monotonic()-start;row={"seconds":elapsed,"owned":owned,"ownedRssKiB":total,"ownedGpuMiB":used,"gpuProcesses":vram};samples.append(row)
  with (out/"resources.jsonl").open("a") as f:f.write(json.dumps(row)+"\n")
  if elapsed>180:stop="wall-bound"
  elif total>8192*1024:stop="owned-rss-bound"
  elif used>8192:stop="owned-gpu-bound"
  if stop:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.2)
 code=p.wait()
deadline=time.monotonic()+5
while time.monotonic()<deadline:
 table=processes();alive=[v for pid,v in observed.items() if pid in table and table[pid]["startTicks"]==v["startTicks"]]
 if not alive:break
 time.sleep(.1)
if alive:
 os.killpg(p.pid,signal.SIGTERM);time.sleep(.5)
 table=processes();alive=[v for pid,v in observed.items() if pid in table and table[pid]["startTicks"]==v["startTicks"]]
 if alive:os.killpg(p.pid,signal.SIGKILL);time.sleep(.5)
table=processes();alive=[v for pid,v in observed.items() if pid in table and table[pid]["startTicks"]==v["startTicks"]]
receipt={"mode":mode,"command":command,"exitCode":code,"stopReason":stop,"wallMs":(time.monotonic()-start)*1000,"observed":list(observed.values()),"allOwnedAbsent":not alive,"alive":alive,"finalHeadroom":headroom(),"policy":{"wallSeconds":180,"ownedRssMiB":8192,"ownedGpuMiB":8192,"preflightFreeGpuMiB":12288,"preflightAvailableRamMiB":12288,"pollSeconds":.2,"protectedPids":[1475083,4007014]}}
(out/"process-receipt.json").write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
sys.exit(0 if code==0 and not stop and not alive else 1)
