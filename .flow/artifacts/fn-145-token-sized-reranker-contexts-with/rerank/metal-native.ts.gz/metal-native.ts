import { getLlama, LlamaRankingContext, getModuleVersion } from "node-llama-cpp";
import { rerankScenarios, verifyRerankFixturePins } from "../../evals/acceptance/rerank-scenarios";
const root = import.meta.dir;
const output = `${root}/metal-native.json`;
if (await Bun.file(output).exists()) throw Error("Refusing existing output");
await verifyRerankFixturePins();
const path = "/Users/gordon/Library/Caches/gno/models/hf_ggml-org_qwen3-reranker-0.6b-q8_0.gguf";
const hash = new Bun.CryptoHasher("sha256");
for await (const chunk of Bun.file(path).stream()) hash.update(chunk);
const sha256 = hash.digest("hex");
if (sha256 !== "22c9979ce4fbcdc5acdc310c6641c32797eff1aa980b8f7a2db8a8ea23429a48") throw Error("Model pin mismatch");
const llama = await getLlama({gpu:"metal", build:"never"});
if(llama.gpu !== "metal") throw Error("Wrong backend");
let model = await llama.loadModel({modelPath:path});
const manager = {acquireLease:()=>({release(){}}),loadModel:async()=>({ok:true,value:{model}})};
const A = (await import(`${root}/baseline/src/llm/nodeLlamaCpp/rerank.ts`)).NodeLlamaCppRerank;
const B = (await import(`${root}/candidate/src/llm/nodeLlamaCpp/rerank.ts`)).NodeLlamaCppRerank;
let ports = {baseline:new A(manager,path,path),candidate:new B(manager,path,path)};
const proto=LlamaRankingContext.prototype as any;
const original=proto._getEvaluationInput;
let tokens:number[][]=[];
proto._getEvaluationInput=function(q:string,d:string){const result=original.call(this,q,d);tokens.push([...result]);return result;};
let contexts:any[]=[];
function instrument(){const create=model.createRankingContext.bind(model);model.createRankingContext=async function(options){const started=performance.now();const context=await create(options);contexts.push({options:options??null,size:(context as any)._llamaContext.contextSize,createMs:performance.now()-started});return context;};}
instrument();
const receipt:any={source:{baseline:"270c3a74f4f7a3aeb8a60462b4c8e1b4adf45462",candidate:"df9ffe64"},sha256,backend:llama.gpu,bun:Bun.version,native:await getModuleVersion(),pid:process.pid,observations:{baseline:[],candidate:[]},rows:[],status:"incomplete",limitations:["Direct real native rerank ports with minimal manager; does not prove full lifecycle manager or hybrid/Ask.","One shared loaded model, sequential scoring. Candidate retained context may coexist with baseline auto context. No resource improvement claim."]};
await Bun.write(output,JSON.stringify(receipt));
try{
for(const scenario of rerankScenarios()){
 if(scenario.transition === "restart"){
  await ports.candidate.dispose();await ports.baseline.dispose();await model.dispose();model=await llama.loadModel({modelPath:path});instrument();ports={baseline:new A(manager,path,path),candidate:new B(manager,path,path)};
 }
 const tokenizer = model.fileInfo.metadata.tokenizer as any;
 const savedTemplate=tokenizer["chat_template.rerank"];
 if(scenario.transition === "unsupported-template") tokenizer["chat_template.rerank"]=savedTemplate.replace("Given a web search query", "Given a search query");
 for(const side of scenario.order){
  tokens=[];contexts=[];const start=performance.now();
  const result=await ports[side].rerank(scenario.query,scenario.documents);
  const elapsed=performance.now()-start;
  receipt.rows.push({caseId:scenario.caseId,side,durationMs:elapsed,contexts,result});
  if(!result.ok)throw Error(JSON.stringify(result.error));
  receipt.observations[side].push({scores:result.value,tokens,query:scenario.query,documents:scenario.documents,durationMs:elapsed,backend:llama.gpu});
  await Bun.write(output,JSON.stringify(receipt));
  console.log(JSON.stringify({caseId:scenario.caseId,side,elapsed,contexts,scores:result.value}));
 }
 tokenizer["chat_template.rerank"]=savedTemplate;
}
receipt.status="complete";
}catch(error){receipt.error=String(error);process.exitCode=2;}
finally{await Bun.write(output,JSON.stringify(receipt));await ports.candidate.dispose();await ports.baseline.dispose();await model.dispose();await llama.dispose();}
