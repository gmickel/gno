import {rerankScenarios,compareRerankScenarios} from '../../evals/acceptance/rerank-scenarios';
import {canonicalFingerprint} from '../../evals/agentic/canonical';
const root=import.meta.dir;
const native=await Bun.file(`${root}/cuda-native.json`).json();
const commits={baseline:'270c3a74f4f7a3aeb8a60462b4c8e1b4adf45462',candidate:(await Bun.$`git rev-parse df9ffe64`.text()).trim()};
const scenarios=rerankScenarios();
const manifests=Object.fromEntries(['baseline','candidate'].map(role=>[role,{
 schemaVersion:'gno-acceptance-v1',role,identity:{commit:commits[role],indexId:'no-index-direct-rerank',indexSha256:canonicalFingerprint(null),bunVersion:native.bun,nativeDependencies:{'node-llama-cpp':native.native},platform:process.platform,architecture:process.arch},
 fixtureVersion:'rerank-scenarios-v1',fixtures:[{path:'schedule',sha256:canonicalFingerprint(scenarios)}],models:[{role:'reranking',id:'qwen3-reranker-0.6b-q8_0',sha256:native.sha256,tokenizerSha256:native.sha256}],cases:scenarios.map(s=>({caseId:s.caseId,fixtureSha256:canonicalFingerprint(s),surface:'sdk',preset:'native-rerank-only',configuration:{transition:s.transition,order:s.order}})),intendedDeltas:[]
}]));
const result=compareRerankScenarios(manifests as any,native.observations);
await Bun.write(`${root}/cuda-comparison.json`,JSON.stringify({manifests,...result},null,2));
console.log(JSON.stringify(result));
