"""Bounded owned-process execution. CLI: watchdog.py OUT_PREFIX SECONDS RSS_MIB COMMAND..."""
import os,sys,time,json,signal,subprocess,platform
from pathlib import Path
prefix=Path(sys.argv[1]);seconds=float(sys.argv[2]);limit=float(sys.argv[3]);command=sys.argv[4:]
prefix.parent.mkdir(parents=True,exist_ok=True)
if prefix.with_suffix('.receipt.json').exists():raise RuntimeError('Refusing existing receipt')
def pressure():
 if platform.system()!='Darwin':return None
 return subprocess.run(['sysctl','vm.swapusage','kern.memorystatus_vm_pressure_level'],capture_output=True,text=True).stdout
samples=[];reason=None;start=time.monotonic()
with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
 child=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True)
 try:
  while child.poll() is None:
   rows=subprocess.run(['ps','-axo','pid=,pgid=,rss='],capture_output=True,text=True).stdout.splitlines();rss=sum(int(cols[2]) for row in rows if len(cols:=row.split())==3 and int(cols[1])==child.pid);state=pressure();elapsed=time.monotonic()-start;samples.append({'elapsed':elapsed,'rssKiB':rss,'pressure':state})
   if elapsed>seconds:reason='timeout'
   elif rss>limit*1024:reason='rss_limit'
   elif state is not None and 'kern.memorystatus_vm_pressure_level: 1' not in state:reason='memory_pressure'
   if reason:break
   time.sleep(.25)
 finally:
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL)
  code=child.wait()
receipt={'command':command,'pid':child.pid,'exit':code,'stopReason':reason,'wallSeconds':time.monotonic()-start,'samples':samples,'finalPressure':pressure()};prefix.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='samples'}));sys.exit(0 if code==0 and reason is None else 1)
