const source = (await Bun.file(`${import.meta.dir}/package-pins.json`).json()).sourceRoot;
const paths: string[] = [];
const original = process.dlopen;
process.dlopen = function(...args: any[]) {
  const result = Reflect.apply(original, this, args);
  const path = String(args[1]);
  if (path.endsWith(".node")) paths.push(path);
  return result;
};
const cpp = await import(Bun.resolveSync("node-llama-cpp", source+"/package.json"));
const llama = await cpp.getLlama({gpu:"metal", build:"never"});
const binaries = await Promise.all(paths.map(async path => ({path,sha256:new Bun.CryptoHasher("sha256").update(await Bun.file(path).bytes()).digest("hex")})));
console.log(JSON.stringify({backend:llama.gpu,version:await cpp.getModuleVersion(),vram:await llama.getVramState(),allocated:await llama.getLlamaMemoryUsage(),binaries}));
await llama.dispose();
