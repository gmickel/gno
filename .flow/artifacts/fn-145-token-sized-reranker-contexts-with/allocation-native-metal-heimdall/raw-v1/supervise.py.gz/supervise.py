import ctypes, hashlib, json, os, pathlib, signal, subprocess, sys, time

root = pathlib.Path(__file__).resolve().parent
mode = sys.argv[1]
if mode not in ['sized', 'auto']:
    raise RuntimeError('Unknown arm')
policy = {'name': 'heimdall-metal-allocation-v1', 'wallSeconds': 180, 'ownedRssMiB': 8192, 'minimumPhysicalGiB': 128, 'minimumPressureFreePercent': 50, 'minimumMetalReportedFreeGiB': 12, 'reserveGiB': 4, 'normalPressure': 1, 'stopAtWarningOrCritical': True, 'pollSeconds': 0.2, 'protectedPid': 26032}
out = root / mode
out.mkdir(mode=0o700)
pins = json.loads((root / 'package-pins.json').read_text())
fixture = json.loads((root / 'fixture.json').read_text())
assert hashlib.sha256(pathlib.Path(fixture['modelPath']).read_bytes()).hexdigest() == fixture['modelSha256']
for relative, expected in pins['shippedFileHashes'].items():
    assert hashlib.sha256((pathlib.Path(pins['sourceRoot']) / relative).read_bytes()).hexdigest() == expected, relative
for relative, expected in json.loads((root / 'helper-pins.json').read_text()).items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected, relative

def pressure():
    value = ctypes.c_int(); size = ctypes.c_size_t(ctypes.sizeof(value))
    if ctypes.CDLL(None).sysctlbyname(b'kern.memorystatus_vm_pressure_level', ctypes.byref(value), ctypes.byref(size), None, 0) != 0:
        raise RuntimeError('Pressure unavailable')
    return value.value

def processes():
    rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,rss=,lstart=,command='], text=True)
    result = {}
    for line in rows.splitlines():
        fields = line.split(None, 9)
        if len(fields) == 10:
            pid, ppid, pgid, rss = map(int, fields[:4])
            result[pid] = {'pid': pid, 'ppid': ppid, 'pgid': pgid, 'rssKiB': rss, 'birth': ' '.join(fields[4:9]), 'command': fields[9]}
    return result

def headroom():
    memory = subprocess.check_output(['memory_pressure', '-Q'], text=True)
    percent = int(memory.split('free percentage:')[1].strip().strip('%'))
    physical = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True))
    metal = json.loads(subprocess.check_output(['/Users/gordon/.local/bin/bun', '--no-env-file', str(root/'headroom.ts')], text=True))
    return {'at': time.time(), 'pressure': pressure(), 'physicalBytes': physical, 'pressureFreePercent': percent, 'metal': metal, 'memoryPressureRaw': memory, 'vmStat': subprocess.check_output(['vm_stat'], text=True), 'swap': subprocess.check_output(['sysctl', 'vm.swapusage'], text=True)}

if mode == 'auto':
    prior = json.loads((root / 'sized/process-receipt.json').read_text())
    assert prior['exitCode'] == 0 and not prior['stopReason'] and prior['allOwnedAbsent']
    current = processes()
    assert not any(row['pid'] in current and current[row['pid']]['birth'] == row['birth'] for row in prior['observed'])
checks = [headroom()]; time.sleep(1); checks.append(headroom())
(out / 'headroom.json').write_text(json.dumps(checks, indent=2))
assert all(row['pressure'] == 1 and row['physicalBytes'] >= 128*1024**3 and row['pressureFreePercent'] >= 50 and row['metal']['vram']['free'] >= 12*1024**3 and row['metal']['backend'] == 'metal' and row['metal']['version'] == '3.19.1' for row in checks), 'Conservative new-host admission failed'
table = processes(); protected = table.get(26032)
plan = {'mode': mode, 'sourceRoot': pins['sourceRoot'], 'fixture': str(root / 'fixture.json'), 'output': str(out / 'result.json'), 'childLog': str(out / 'child.jsonl')}
(out / 'plan.json').write_text(json.dumps(plan, indent=2))
isolation = out / 'isolation'; isolation.mkdir()
env = {key: os.environ[key] for key in ['PATH', 'USER', 'SHELL'] if key in os.environ}
env.update(HOME=str(isolation/'home'), XDG_CONFIG_HOME=str(isolation/'config'), XDG_DATA_HOME=str(isolation/'data'), XDG_STATE_HOME=str(isolation/'state'), XDG_CACHE_HOME=str(isolation/'cache'), TMPDIR=str(isolation), GNO_OFFLINE='1', GNO_ALLOW_DOWNLOAD='0', GNO_LLAMA_GPU='metal', GNO_LLAMA_BUILD='never')
command = ['/Users/gordon/.local/bin/bun', '--no-env-file', str(root/'run.ts'), str(out/'plan.json'), '--native']
started = time.monotonic(); observed = {}; stop = None
with (out/'stdout.log').open('w') as stdout, (out/'stderr.log').open('w') as stderr:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try:
        while process.poll() is None:
            table = processes(); ids = {process.pid}
            for _ in range(8):
                ids |= {pid for pid, row in table.items() if row['ppid'] in ids or row['pgid'] == process.pid}
            assert 26032 not in ids
            owned = [row for pid, row in table.items() if pid in ids]
            for row in owned:
                observed[row['pid']] = row
            elapsed = time.monotonic()-started; level = pressure(); rss = sum(row['rssKiB'] for row in owned)
            with (out/'resources.jsonl').open('a') as stream:
                stream.write(json.dumps({'seconds': elapsed, 'pressure': level, 'owned': owned, 'ownedRssKiB': rss, 'protected': table.get(26032)})+'\n')
            if elapsed > 180: stop = 'wall-bound'
            elif level != 1: stop = f'pressure-{level}'
            elif rss > 8192*1024: stop = 'owned-rss-bound'
            if stop: break
            time.sleep(.2)
    except Exception as error:
        stop = 'governor-error:'+str(error)
    if stop:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=5)
        except subprocess.TimeoutExpired: os.killpg(process.pid, signal.SIGKILL); process.wait()
    code = process.wait()
deadline = time.monotonic()+5
while True:
    table = processes(); alive = [row for pid,row in observed.items() if pid in table and table[pid]['birth'] == row['birth']]
    if not alive or time.monotonic() >= deadline: break
    time.sleep(.1)
if alive:
    os.killpg(process.pid, signal.SIGTERM); time.sleep(.5)
    table = processes(); alive = [row for pid,row in observed.items() if pid in table and table[pid]['birth'] == row['birth']]
    if alive: os.killpg(process.pid, signal.SIGKILL); time.sleep(.5)
table = processes(); alive = [row for pid,row in observed.items() if pid in table and table[pid]['birth'] == row['birth']]
receipt = {'mode': mode, 'command': command, 'exitCode': code, 'stopReason': stop, 'wallMs': (time.monotonic()-started)*1000, 'observed': list(observed.values()), 'allOwnedAbsent': not alive, 'alive': alive, 'protectedBefore': protected, 'protectedAfter': table.get(26032), 'policy': policy, 'finalHeadroom': headroom()}
(out/'process-receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps({key:receipt[key] for key in ['mode','exitCode','stopReason','wallMs','allOwnedAbsent']}))
sys.exit(0 if code == 0 and not stop and not alive else 1)
