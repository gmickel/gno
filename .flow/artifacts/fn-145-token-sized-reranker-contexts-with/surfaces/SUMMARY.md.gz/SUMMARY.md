# fn145.3 native hybrid/Ask support — incomplete

Selected product sources are frozen baseline270c3a74f4f7a3aeb8a60462b4c8e1b4adf45462 and candidate df9ffe64a89bcae3fdd13701d0914dd3b3a8c2c3. `source-identity.json` verifies all716/720 product source files against archives; no dirty working-source changes used. Archive SHA256 values are ca991b29e0e23451290b82f8999fbca8725f20e4ac684e2acbc09ead9fd86d73 and2631d4cf97e103533950f7f1723dc31f1b5952af3d54f9448dde41d5c8e5a7ec. Both runtimes Bun1.3.14, node-llama-cpp3.19.1; models pinned in side manifests and verified by native capture on actual load.

Supplementary source-backed30doc orchid corpus, original shared physical provenance paths within each host; independent SQLite backup per side. Exact five declared SDK requests in `cuda-plan-v2.json` / `metal-raw/plan-v2.json`: short hybrid; 6000CJK-character query plus ownership question; short hybrid; verified Ask; verified Ask after2500ms idle. Explicit warmModelTtl1200, noExpand:true,noRerank:false,graph:false,default answer/context budgets. This short-TTL scenario deliberately exposes unload/reload paths; it is not the default300000ms lifecycle configuration. Native query embedding emits its existing3022→2044token truncation warning on the long query; rerank receives captured full prepared query/passages. No QA-side input truncation or context changes.

`retained-sdk.ts` installs read-only evidence wrappers around selected ModelManager.loadModel/model.createRankingContext/model.createContext, preserving exact arguments and outputs. `contexts.json` records actual native requested and resolved context sizes; raw `*.json.gz` records retain actual model inputs/outputs, passages, scores, verification/citations and capabilities. Those wrappers are scratch code, not product edits. Public CLI/MCP/REST surfaces were not driven in this support phase; these are actual SDK pipeline observations.

## Results

| Host/side | Completed records | Outcome |
|---|---:|---|
| Metal baseline v1 |0/5|Auto ranking context40960 observed; pressure2 watchdog stops at3.29s during first hybrid. No favorable rerun.|
| Metal candidate v1 |5/5,3complete|Hybrid short/long/short complete. Ask blocked by fixture DB basename bug.|
| Metal baseline v2 |0/5|Not rerun after baseline pressure failure; no synthetic baseline records substituted.|
| Metal candidate v2 |5/5,3complete|Hybrid3/3complete; actual ranking sizes768→3840→768. Both Ask generation calls return INFERENCE_FAILED/Object is disposed; semantic modelCalls0/no_candidates, incomplete.|
| CUDA baseline v1 |5/5,2complete|Shorts complete; long rerank Object is disposed. Ask fixture-limited.|
| CUDA baseline v2 |3/5,2complete|Shorts complete; long rerank Object is disposed. During verified-before, pure virtual method called, exit-6; no completed Ask record.|
| CUDA candidate v2 |0/5|Pure virtual method called + Bun segmentation fault before first record, exit-4. No retry.|

V1 fixture bug: new SQLite basename `index.sqlite` made Ask provenance validation report `Index snapshot for probe belongs to index, not default`. V2 uses fresh backup from the original clean DB and preserves its `index-default.sqlite` basename. All v1 failures remain unchanged and explicitly fixture-limited. V2 removes that setup error but exposes actual native lifecycle failures. No product config/threshold/model changes disguised those failures.

Both `cuda-comparison.json` and `metal-comparison.json` fail with five missing-case failures and zero comparable pairs. Complete candidate Metal hybrid records do not establish baseline/candidate equality when baseline failed. Actual semantic-judge execution remains **unmet** for this phase. The earlier fn143 judge controls are not substituted. Context size transitions here coincide with short-TTL model lifecycle; do not claim they alone prove same-model retained-context resize. Low-level retained-model resize evidence belongs to rerank_scenarios' separate suite.

New confirmed Ask failure specificity: CUDA baseline v2 `contexts.json` reaches `verified-before`, including rerank context40960, then stderr reports pure virtual method called. This is stronger/new evidence than earlier Bun1.3.11 Ask segfault and is not retroactively attributed to that earlier run. Root cause remains unresolved; candidate also crashes in first hybrid, so no fix claim.

## Reproduction and evidence

- Remote scratch: `/tmp/fn145-qa-surfaces`; frozen baseline/candidate sources there, side evidence, original plan/script/watchdogs. Local copied remote outputs: `metal-raw/`.
- CPU preparation: `prepare.py`, `prepare-cuda.py`, `revise-db-name.py`. Do not rerun against existing evidence roots; they intentionally refuse existing output directories.
- Native commands used: `python3 run-cuda-v2.py baseline`, then candidate; on Ivan `python3 /tmp/fn145-qa-surfaces/run-v2.py candidate`. Baseline original uses `run.py baseline`. All run the selected-source SDK through `retained-sdk.ts --native PLAN SIDE`.
- Bounds:240seconds, CUDA8192MiB/Metal6144MiB owned-group RSS; Metal pressure1 required, stops2. Exact raw stdout/stderr/exit/resource samples in `*-watchdog*.{stdout,stderr,receipt.json}`. CandidateMetal v2 completed25.88s with terminalpressure1; baselineCUDA25.72s abort; candidateCUDA12.72s abort.
- Full raw records/manifests/configs/context events under `{cuda-baseline-v2,cuda-candidate-v2,metal-raw/*-evidence-v2}`; no arbitrary deterministic field projection added. `compare.ts` uses frozen committed fn143 comparator and retains missing cases.

Both GPUs returned to rerank_scenarios after this phase. No native workload remains. No tracked product/harness files, Git state, Flow state, live configuration/index/service or model downloads changed. This artifact is support evidence, not task completion or promotion.
