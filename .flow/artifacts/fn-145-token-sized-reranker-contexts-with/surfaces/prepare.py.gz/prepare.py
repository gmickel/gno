"""CPU-only preparation from exact archives and existing synthetic source/index."""
import pathlib,json,sqlite3,hashlib,shutil,tarfile
root=pathlib.Path('/tmp/fn145-qa-surfaces'); old=pathlib.Path('/tmp/fn143-orchid-metal-01')
root.mkdir(exist_ok=True)
if (root/'plan.json').exists():raise RuntimeError('Preserve existing plan')
sources={}
for side in ['baseline','candidate']:
 target=root/side;target.mkdir()
 archive=pathlib.Path('/tmp/gno-native-baseline-20260905.VQtXt5/source.tar') if side=='baseline' else root/'candidate.tar'
 with tarfile.open(archive) as tar:
  commit=tar.pax_headers['comment'];tar.extractall(target,filter='data')
 shutil.copytree('/tmp/gno-native-baseline-20260905.VQtXt5/source/evals/acceptance',target/'evals/acceptance',dirs_exist_ok=True)
 (target/'node_modules').symlink_to('/Users/gordon/.bun/install/global/node_modules')
 sources[side]={'sourceRoot':str(target),'commit':commit,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
requests=[]
short='Who owns the meadow migration?'
for name,query,op,idle in [('short-before',short,'hybrid',0),('long-resize','迁移负责人。'*1000+' '+short,'hybrid',0),('short-after',short,'hybrid',0),('verified-before',short,'verified-ask',0),('verified-after-idle',short,'verified-ask',2500)]:
 options={'collection':'probe','limit':3,'noExpand':True,'noRerank':False,'graph':False}
 requests.append({'caseId':name,'query':query,'operation':op,'options':options,'expectedBackend':'metal','idleMs':idle})
for side in ['baseline','candidate']:
 out=root/(side+'-evidence');out.mkdir()
 init=json.loads((old/side/'init.json').read_text()); db=out/'index.sqlite'
 with sqlite3.connect(init['dbPath']) as a,sqlite3.connect(db) as b:a.backup(b)
 init['dbPath']=str(db);init['config']['models']['warmModelTtl']=1200
 (out/'init.json').write_text(json.dumps(init,indent=2))
 m=json.loads((old/side/'manifest-orchid-verified.json').read_text());m['identity']['commit']=sources[side]['commit'];m['identity']['indexSha256']=hashlib.sha256(db.read_bytes()).hexdigest()
 base=m['cases'][0];m['cases']=[]
 for request in requests:
  c=json.loads(json.dumps(base));c['caseId']=request['caseId'];c['configuration']={'operation':request['operation'],'query':request['query'],'options':request['options'],'warmModelTtl':1200,'idleMs':request['idleMs'],'request':{k:v for k,v in request.items() if k not in ['caseId','idleMs']}};m['cases'].append(c)
 (out/'manifest.json').write_text(json.dumps(m,indent=2))
 sources[side].update(output=str(out),manifestPath=str(out/'manifest.json'),initPath=str(out/'init.json'))
(root/'plan.json').write_text(json.dumps({**sources,'requests':requests,'provenanceRoot':str(old/'corpus'),'fixtureSource':str(old/'fixtures.json'),'scope':'Declared supplementary surface sequence, not original143doc acceptance'},indent=2))
