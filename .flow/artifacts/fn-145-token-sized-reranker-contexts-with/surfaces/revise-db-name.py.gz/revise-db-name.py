"""Separate fixture correction: preserve product index-default SQLite basename."""
import pathlib,json,sqlite3,hashlib,sys
planpath=pathlib.Path(sys.argv[1]);plan=json.loads(planpath.read_text());old=pathlib.Path(plan['provenanceRoot']).parent
for side in ['baseline','candidate']:
 prior=plan[side];out=pathlib.Path(prior['output']+'-v2');out.mkdir()
 init=json.loads((old/side/'init.json').read_text());db=out/'index-default.sqlite'
 with sqlite3.connect(init['dbPath']) as a,sqlite3.connect(db) as b:a.backup(b)
 init['dbPath']=str(db);init['config']['models']['warmModelTtl']=1200;(out/'init.json').write_text(json.dumps(init,indent=2))
 m=json.loads(pathlib.Path(prior['manifestPath']).read_text());m['identity']['indexSha256']=hashlib.sha256(db.read_bytes()).hexdigest();(out/'manifest.json').write_text(json.dumps(m,indent=2))
 prior.update(output=str(out),initPath=str(out/'init.json'),manifestPath=str(out/'manifest.json'))
plan['fixtureCorrection']='Original SQLite basename restored; v1 Ask rows fixture-limited, retained unchanged.'
planpath.with_name(planpath.stem+'-v2.json').write_text(json.dumps(plan,indent=2))
