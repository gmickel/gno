"""Execute one granted Metal side, preserving owned evidence and resource limits."""
import pathlib,os,sys,subprocess,json
r=pathlib.Path('/tmp/fn145-qa-surfaces');side=sys.argv[1]
if side not in ['baseline','candidate']:raise RuntimeError('Invalid side')
env=dict(os.environ,GNO_LLAMA_GPU='metal',GNO_LLAMA_BUILD='never',GNO_OFFLINE='1',GNO_ALLOW_DOWNLOAD='0')
for key,name in {'HOME':'home','XDG_CONFIG_HOME':'config','XDG_DATA_HOME':'data','XDG_STATE_HOME':'state','XDG_CACHE_HOME':'cache','GNO_CONFIG_DIR':'config/gno','GNO_DATA_DIR':'data/gno','GNO_CACHE_DIR':'cache/gno'}.items():
 d=r/(side+'-evidence')/name;d.mkdir(parents=True,exist_ok=True);env[key]=str(d)
subprocess.run(['python3','/tmp/gno-native-baseline-20260905.VQtXt5/watchdog.py',str(r/(side+'-watchdog')),'240','6144','/tmp/gno-native-tools-1314.KrONBb/bun-darwin-aarch64/bun',str(r/'retained-sdk.ts'),'--native',str(r/'plan.json'),side],env=env,check=False)
