import pathlib,json,sqlite3,hashlib,tarfile
r=pathlib.Path(__file__).resolve().parent;old=r.parents[1]/'fn143-native-tmp/qa-prep/runs/cuda-orchid-01'
remote=json.loads((r/'metal-plan.json').read_text());plan={'requests':remote['requests'],'provenanceRoot':str(old/'corpus'),'fixtureSource':str(old/'fixtures.json')}
for request in plan['requests']:request['expectedBackend']='cuda'
for side in ['baseline','candidate']:
 out=r/('cuda-'+side);out.mkdir()
 init=json.loads((old/side/'init.json').read_text());db=out/'index.sqlite'
 with sqlite3.connect(init['dbPath']) as a,sqlite3.connect(db) as b:a.backup(b)
 init['dbPath']=str(db);init['config']['models']['warmModelTtl']=1200;(out/'init.json').write_text(json.dumps(init,indent=2))
 archive=r/(side+'.tar')
 with tarfile.open(archive) as t:commit=t.pax_headers['comment']
 m=json.loads((old/side/'manifest-orchid-verified.json').read_text());m['identity']['commit']=commit;m['identity']['indexSha256']=hashlib.sha256(db.read_bytes()).hexdigest();base=m['cases'][0];m['cases']=[]
 for request in plan['requests']:
  c=json.loads(json.dumps(base));c['caseId']=request['caseId'];c['configuration']={'operation':request['operation'],'query':request['query'],'options':request['options'],'warmModelTtl':1200,'idleMs':request['idleMs'],'request':{k:v for k,v in request.items() if k not in ['caseId','idleMs']}};m['cases'].append(c)
 (out/'manifest.json').write_text(json.dumps(m,indent=2));plan[side]={'sourceRoot':str(r/side),'commit':commit,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'output':str(out),'manifestPath':str(out/'manifest.json'),'initPath':str(out/'init.json')}
(r/'cuda-plan.json').write_text(json.dumps(plan,indent=2))
