/** Missing/failed native evidence stays visible; never compare success subsets. */
const [planPath,output,baselineOutput,candidateOutput]=process.argv.slice(2);
const plan=await Bun.file(planPath).json();
const {compareAcceptance}=await import(`${import.meta.dir}/candidate/evals/acceptance/compare.ts`);
const sides=[];
for(const [side,root] of [['baseline',baselineOutput],['candidate',candidateOutput]]) {
 const manifest=await Bun.file(`${root}/manifest.json`).json();const records=[],coverage=[];
 for(const req of plan.requests) {
  const file=Bun.file(`${root}/${req.caseId}.json.gz`);
  if(!await file.exists()){coverage.push({caseId:req.caseId,status:'incomplete',reason:'No completed native record'});continue;}
  const result=JSON.parse(new TextDecoder().decode(Bun.gunzipSync(await file.arrayBuffer())));
  records.push(result.record);coverage.push({caseId:req.caseId,status:result.coverage,reasons:result.reasons});
 }
 sides.push({side,manifest,records,coverage});
}
const comparison=compareAcceptance(sides[0].manifest,sides[1].manifest,sides[0].records,sides[1].records);
await Bun.write(output,JSON.stringify({coverage:sides.map(s=>({side:s.side,cases:s.coverage})),comparison,status:'incomplete'},null,2));
console.log(JSON.stringify({passed:comparison.passed,comparedCases:comparison.comparedCases,failures:comparison.failures.length}));
