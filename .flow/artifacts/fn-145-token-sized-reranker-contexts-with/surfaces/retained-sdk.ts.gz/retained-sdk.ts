/** Scratch native evidence only. Selected source imports; no changed inference args. */
const [flag, planPath, side] = process.argv.slice(2);
if(flag!=='--native'||!['baseline','candidate'].includes(side))throw Error('Explicit native opt-in required');
const plan=await Bun.file(planPath).json(), selected=plan[side];
const events:unknown[]=[];let phase='setup';
const emit=async(event:unknown)=>{events.push({phase,event});await Bun.write(`${selected.output}/contexts.json`,JSON.stringify(events,null,2));};
const {ModelManager}=await import(`${selected.sourceRoot}/src/llm/nodeLlamaCpp/lifecycle.ts`);
const original=ModelManager.prototype.loadModel, tapped=new WeakSet();
ModelManager.prototype.loadModel=async function(...args:unknown[]) {
  const result=await original.apply(this,args);
  if(result.ok&&!tapped.has(result.value.model)) {
    const model=result.value.model;tapped.add(model);
    const ranking=model.createRankingContext, context=model.createContext;
    model.createRankingContext=async function(...input:unknown[]) {
      await emit({kind:'ranking-request',modelUri:result.value.uri,args:input});
      const out=await ranking.apply(this,input);
      await emit({kind:'ranking-created',modelUri:result.value.uri});return out;
    };
    model.createContext=async function(...input:unknown[]) {
      const out=await context.apply(this,input);
      await emit({kind:'context-created',modelUri:result.value.uri,args:input,actualContextSize:out.contextSize});return out;
    };
  }
  return result;
};
const {createNativeAcceptanceSession}=await import(`${selected.sourceRoot}/evals/acceptance/native-adapter.ts`);
const manifest=await Bun.file(selected.manifestPath).json(),init=await Bun.file(selected.initPath).json();
const session=await createNativeAcceptanceSession(manifest,init);
try {
 for(const request of plan.requests) {
   phase=request.caseId;
   if(request.idleMs)await new Promise(resolve=>setTimeout(resolve,request.idleMs));
   const result=await session.run({...request,manifest});
   await Bun.write(`${selected.output}/${phase}.json.gz`,Bun.gzipSync(JSON.stringify(result)));
   console.log(JSON.stringify({phase,coverage:result.coverage,reasons:result.reasons,semantic:result.raw?.verification?.semantic}));
 }
} finally {await session.close();ModelManager.prototype.loadModel=original;}
