import pathlib,os,subprocess,sys
r=pathlib.Path(__file__).resolve().parent;side=sys.argv[1]
if side not in ['baseline','candidate']:raise RuntimeError('Invalid side')
env=dict(os.environ,GNO_LLAMA_GPU='cuda',GNO_LLAMA_BUILD='never',CUDA_PATH='/opt/cuda',GNO_OFFLINE='1',GNO_ALLOW_DOWNLOAD='0')
for key,name in {'HOME':'home','XDG_CONFIG_HOME':'config','XDG_DATA_HOME':'data','XDG_STATE_HOME':'state','XDG_CACHE_HOME':'cache','GNO_CONFIG_DIR':'config/gno','GNO_DATA_DIR':'data/gno','GNO_CACHE_DIR':'cache/gno'}.items():
 d=r/('cuda-'+side+'-v2')/name;d.mkdir(parents=True,exist_ok=True);env[key]=str(d)
subprocess.run(['python3',str(r.parents[1]/'fn143-native-tmp/qa-prep/watchdog.py'),str(r/('cuda-'+side+'-watchdog-v2')),'240','8192','/home/gordon/.local/share/mise/installs/bun/1.3.14/bin/bun',str(r/'retained-sdk.ts'),'--native',str(r/'cuda-plan-v2.json'),side],env=env)
