import pathlib,json,hashlib,sys
root=pathlib.Path(sys.argv[1]);source=pathlib.Path(sys.argv[2]);manifest=json.loads(pathlib.Path(sys.argv[3]).read_text());bun=pathlib.Path(sys.argv[4]);out=pathlib.Path(sys.argv[5])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=manifest.get('shippedFileHashes') or {x['path']:x['sha256'] for x in manifest['files']}
assert all(sha(source/p)==h for p,h in files.items())
cpp=source/'node_modules/node-llama-cpp';lib=json.loads((cpp/'package.json').read_text());native={}
for package in (source/'node_modules/@node-llama-cpp').iterdir():
 if ('mac-arm64-metal' in package.name or 'linux-x64-cuda' in package.name):
  for p in package.rglob('*'):
   if p.is_file() and (p.suffix in ['.node','.so','.dylib'] or p.name=='package.json'):native[str(p.resolve())]=sha(p)
receipt={'sourceRoot':str(source),'filesVerified':len(files),'sourceFiles':files,'bunPath':str(bun),'bunSha256':sha(bun),'cppVersion':lib['version'],'cppPackageSha256':sha(cpp/'package.json'),'cppJavaScriptHashes':{str(p.relative_to(cpp)):sha(p) for p in (cpp/'dist').rglob('*.js')},'nativeBinaryHashes':native}
out.write_text(json.dumps(receipt,indent=2))
print(json.dumps({'filesVerified':len(files),'cppVersion':lib['version'],'nativeFiles':len(native),'out':str(out)}))
