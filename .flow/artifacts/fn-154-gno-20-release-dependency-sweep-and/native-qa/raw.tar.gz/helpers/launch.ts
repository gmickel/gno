export function captureOptions(options:any,source:string,preload:string,output:string,mode:string) {
 if(Array.isArray(options)||!options?.cmd?.includes(source+"/src/llm/native-worker/entry.ts"))return options;
 return {...options,cmd:[options.cmd[0],"--preload",preload,...options.cmd.slice(1)],
 env:{...options.env,ALLOCATION_SOURCE:source,ALLOCATION_OUTPUT:output,ALLOCATION_MODE:mode}};
}
