import pathlib,json,subprocess,hashlib,os,signal,time,sys,ctypes
if len(sys.argv)!=3 or sys.argv[2]!='--native':raise SystemExit('Explicit --native required')
cfg=json.loads(pathlib.Path(sys.argv[1]).read_text());root=pathlib.Path(cfg['root']);root.mkdir(parents=True,exist_ok=False)
metal=cfg['platform']=='metal';helpers=pathlib.Path(cfg['helperRoot']);source=pathlib.Path(cfg['sourceRoot'])
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def ps():
 result={}
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,rss=,lstart=,command='],text=True).splitlines():
  f=line.split(None,9)
  if len(f)==10:
   pid,ppid,pgid,rss=map(int,f[:4]);result[pid]={'pid':pid,'ppid':ppid,'pgid':pgid,'rssKiB':rss,'birth':' '.join(f[4:9]),'command':f[9]}
 return result
def pressure():
 v=ctypes.c_int();n=ctypes.c_size_t(ctypes.sizeof(v))
 assert ctypes.CDLL(None).sysctlbyname(b'kern.memorystatus_vm_pressure_level',ctypes.byref(v),ctypes.byref(n),None,0)==0
 return v.value
def gpu():
 rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True)
 return [{'pid':int(x.split(',')[0]),'mib':int(x.split(',')[1])} for x in rows.splitlines()]
def headroom():
 if metal:
  raw=subprocess.check_output(['memory_pressure','-Q'],text=True)
  return {'pressure':pressure(),'physicalBytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'pressureFreePercent':int(raw.split('free percentage:')[1].strip().strip('%')),'swap':subprocess.check_output(['sysctl','vm.swapusage'],text=True),'raw':raw}
 return {'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=memory.total,memory.used,memory.free','--format=csv,noheader,nounits'],text=True),'processes':gpu(),'meminfo':pathlib.Path('/proc/meminfo').read_text()}
fixture=json.loads((helpers/'fixture.json').read_text());fixture['modelPath']=cfg['modelPath'];assert sha(cfg['modelPath'])==cfg['modelSha256'];(root/'fixture.json').write_text(json.dumps(fixture,indent=2))
assert json.loads((source/'node_modules/node-llama-cpp/package.json').read_text())['version']==cfg['cppVersion']
receipt={'config':cfg,'runtimeSha256':sha(cfg['bun']),'runtimeVersion':subprocess.check_output([cfg['bun'],'--version'],text=True).strip(),'helperHashes':{str(p.name):sha(p) for p in helpers.iterdir() if p.is_file()},'modelSha256':sha(cfg['modelPath'])}
before=headroom();receipt['admission']=before
if metal:assert before['pressure']==1 and before['physicalBytes']>=128*1024**3 and before['pressureFreePercent']>=50
else:
 assert int(before['gpu'].strip().split(',')[-1])>=12288
 assert int(next(x for x in before['meminfo'].splitlines() if x.startswith('MemAvailable:')).split()[1])>=12*1024**2
protected=ps();protectedGpu=[] if metal else before['processes'];observed={};stop=None
(root/'preflight.json').write_text(json.dumps(receipt,indent=2))
plan={'sourceRoot':str(source),'fixture':str(root/'fixture.json'),'output':str(root/'result.json'),'childLog':str(root/'child.jsonl'),'mode':'sized'}
(root/'plan.json').write_text(json.dumps(plan,indent=2))
env={k:os.environ[k] for k in ['PATH','USER','SHELL'] if k in os.environ};env.update(GNO_LLAMA_GPU=cfg['platform'],GNO_LLAMA_BUILD='never',GNO_OFFLINE='1',GNO_ALLOW_DOWNLOAD='0',GNO_QA_SUPERVISED='1',NODE_ENV='production')
if not metal:env['CUDA_PATH']='/opt/cuda'
for k,n in {'HOME':'home','XDG_CONFIG_HOME':'config','XDG_DATA_HOME':'data','XDG_STATE_HOME':'state','XDG_CACHE_HOME':'cache','TMPDIR':'tmp'}.items():
 d=root/n;d.mkdir();env[k]=str(d)
command=[cfg['bun'],'--no-env-file',str(helpers/cfg.get('driver','run.ts')),str(root/'plan.json'),'--native']
if cfg.get('driver'):plan.update(cfg);(root/'plan.json').write_text(json.dumps(plan,indent=2))
started=time.monotonic()
with (root/'stdout.log').open('w') as out,(root/'stderr.log').open('w') as err:
 child=subprocess.Popen(command,env=env,cwd=source,stdout=out,stderr=err,start_new_session=True)
 try:
  while child.poll() is None:
   table=ps();ids={child.pid}
   for _ in range(8):ids|={pid for pid,p in table.items() if p['ppid'] in ids or p['pgid']==child.pid}
   assert not any(p['pid'] in ids for p in protectedGpu)
   owned=[p for pid,p in table.items() if pid in ids]
   for p in owned:observed[p['pid']]=p
   elapsed=time.monotonic()-started;rss=sum(p['rssKiB'] for p in owned);level=pressure() if metal else None;vram=[] if metal else gpu();used=sum(p['mib'] for p in vram if p['pid'] in ids)
   with (root/'resources.jsonl').open('a') as f:f.write(json.dumps({'seconds':elapsed,'owned':owned,'ownedRssKiB':rss,'pressure':level,'gpu':vram,'ownedGpuMiB':used})+'\n')
   if elapsed>cfg['wallSeconds']:stop='wall-bound'
   elif rss>cfg['rssMiB']*1024:stop='rss-bound'
   elif metal and level!=1:stop='pressure-'+str(level)
   elif not metal and used>cfg['gpuMiB']:stop='gpu-bound'
   if stop:break
   time.sleep(.2)
 except BaseException as e:stop='supervisor-error:'+str(e)
 if stop:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL)
 code=child.wait()
deadline=time.monotonic()+5
while True:
 table=ps();alive=[p for pid,p in observed.items() if pid in table and table[pid]['birth']==p['birth']]
 if not alive or time.monotonic()>deadline:break
 time.sleep(.1)
if alive:
 os.killpg(child.pid,signal.SIGKILL);time.sleep(.3)
 table=ps();alive=[p for pid,p in observed.items() if pid in table and table[pid]['birth']==p['birth']]
receipt.update(command=command,exitCode=code,stopReason=stop,wallMs=(time.monotonic()-started)*1000,observed=list(observed.values()),allOwnedAbsent=not alive,alive=alive,finalHeadroom=headroom())
(root/'process-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({k:receipt[k] for k in ['exitCode','stopReason','wallMs','allOwnedAbsent']}))
sys.exit(0 if code==0 and not stop and not alive else 1)
