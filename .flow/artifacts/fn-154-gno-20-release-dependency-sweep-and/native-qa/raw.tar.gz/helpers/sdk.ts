import {mkdir} from 'node:fs/promises'; // Bun lacks directory creation.
import {readFileSync} from 'node:fs'; // Synchronous observation of termination-safe phase log.
import {installPhaseBridge} from './phase-parent';
import {observeOwnership} from './ownership-observer';
const plan=await Bun.file(process.argv[2]!).json();
if(process.argv[3]!=='--native'||process.env.GNO_QA_SUPERVISED!=='1')throw Error('Supervisor opt-in required');
const root=plan.root,source=plan.sourceRoot;
const fixture=await Bun.file(`${plan.helperRoot}/sdk-fixture.json`).json();
const init=structuredClone(await Bun.file(plan.initPath).json());
init.dbPath=plan.dbPath??`${root}/data/index-default.sqlite`;init.cacheDir=`${root}/cache`;
if(plan.phase==='idle')init.config.models.warmModelTtl=1200;
const events:any[]=[];const results:any[]=[];const emit=(e:any)=>events.push({at:Date.now(),...e});
const save=()=>Bun.write(`${root}/result.json`,JSON.stringify({plan,init,events,results},null,2));
await mkdir(`${root}/capture`,{mode:0o700});
const restorePhase=installPhaseBridge(source,`${root}/phases.jsonl`);
const {installParentCapture}=await import(`${source}/evals/acceptance/parent-capture.ts`);
const {createGnoClient}=await import(`${source}/src/sdk/client.ts`);
const capture=await installParentCapture(crypto.randomUUID(),plan.models,`${root}/capture`,undefined,(e:any)=>emit({kind:'child',value:e}));
const client:any=await createGnoClient({...init,downloadPolicy:{offline:true,allowDownload:false}});
const worker=client.llm.worker;
const state=()=>({pid:worker.processId,generation:worker.currentGeneration,ownership:observeOwnership(worker)});
const options={...fixture.options};
const poll=async(fn:()=>boolean,ms=10000)=>{const until=performance.now()+ms;while(performance.now()<until){if(fn())return true;await Bun.sleep(2);}return false;};
const outcome=async(p:Promise<any>)=>{try{return{ok:true,value:await p};}catch(e:any){return{ok:false,error:{name:e?.name,message:e?.message,code:e?.code}};}};
async function stage(label:string,fn:()=>Promise<any>){capture.begin(label);const before=state(),start=performance.now();const result=await fn();const end=performance.now();results.push({label,result,start,end,before,after:state(),capture:structuredClone(capture.finish())});await save();return result;}
const query=()=>client.query(fixture.query,options);
function pending(op:string,after:number){
 let rows:any[];try{rows=readFileSync(`${root}/phases.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);}catch{return;}
 return rows.findLast(r=>r.at>=after&&r.event.kind==='evaluation-pending'&&r.event.method==='next'&&r.event.request?.op===op&&!rows.some(e=>e.pid===r.pid&&e.event.evaluationId===r.event.evaluationId&&e.event.id===r.event.id&&['evaluation-end','evaluation-error'].includes(e.event.kind)));
}
try{
 if(plan.phase==='quality'){
  await stage('index',()=>client.index({collection:'probe'}));
  await stage('vsearch',()=>client.vsearch(fixture.query,{collection:'probe',limit:3}));
  await stage('query',query);
  await stage('ask',()=>client.ask(fixture.query,{...options,verify:true,showSources:true}));
 }else if(plan.phase==='idle'){
  await stage('before-idle',query);await stage('warm',query);
  const rows=[];const end=performance.now()+3000;
  while(performance.now()<end){rows.push({at:Date.now(),state:state(),lifecycle:client.llm.getLifecycleStats?.()});await Bun.sleep(100);}
  emit({kind:'idle-polls',rows});await stage('after-idle',query);
 }else if(plan.phase==='cancel'){
  await stage('control',query);
  await stage('pre-aborted',async()=>{const a=new AbortController();a.abort();return outcome(client.query(fixture.query,{...options,signal:a.signal}));});
  await stage('pre-aborted-recovery',query);
  const created=await client.llm.createRerankPort(undefined,{egressCollections:['probe'],policy:{offline:true,allowDownload:false}});if(!created.ok)throw Error(JSON.stringify(created.error));
  const rerank=created.value;
  await stage('queued',async()=>{let done=false;const at=Date.now();const primary=outcome(rerank.rerank(fixture.rerank.query,fixture.rerank.documents)).finally(()=>done=true);await poll(()=>Boolean(pending('rerank',at))||done);const controller=new AbortController();const next=outcome(rerank.rerank(fixture.rerank.query,fixture.rerank.documents,{signal:controller.signal}));await poll(()=>worker.owner?.pending.length>=2||done);const before=state();controller.abort();return{before,primary:await primary,cancelled:await next};});
  await stage('queued-recovery',query);
  for(const op of ['rerank','generate']){
   await stage(`active-${op}`,async()=>{let port=rerank;if(op==='generate'){const c=await client.llm.createGenerationPort(undefined,{egressCollections:['probe'],policy:{offline:true,allowDownload:false}});if(!c.ok)throw Error(JSON.stringify(c.error));port=c.value;}
    const c=new AbortController(),at=Date.now();let done=false;const call=outcome(op==='rerank'?port.rerank(fixture.rerank.query,fixture.rerank.documents,{signal:c.signal}):port.generate(fixture.generation.prompt,fixture.generation.params,{signal:c.signal})).finally(()=>done=true);await poll(()=>Boolean(pending(op,at))||done);const phase=pending(op,at),before=state();const exercised=Boolean(phase&&!done);emit({kind:'abort',op,phase,before});c.abort();const result=await call;return{exercised,phase,before,result,afterCaller:state()};
   });await stage(`active-${op}-recovery`,query);
  }
 }
}catch(e){emit({kind:'error',error:String(e)});process.exitCode=1;}
finally{const start=performance.now();await client.close();emit({kind:'closed',start,end:performance.now(),state:state()});capture.restore();restorePhase();await save();}
