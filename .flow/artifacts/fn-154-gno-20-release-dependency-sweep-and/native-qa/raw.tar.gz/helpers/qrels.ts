import {mkdir} from 'node:fs/promises'; // Bun lacks mkdir.
const p=await Bun.file(process.argv[2]!).json();
if(process.argv[3]!=='--native'||process.env.GNO_QA_SUPERVISED!=='1')throw Error('Supervisor required');
const init=await Bun.file(p.initPath).json();init.dbPath=`${p.root}/data/index-default.sqlite`;init.cacheDir=`${p.root}/cache`;
const fixture=await Bun.file(p.queriesPath).json();
await mkdir(`${p.root}/capture`,{mode:0o700});
const {installParentCapture}=await import(`${p.sourceRoot}/evals/acceptance/parent-capture.ts`);
const {createGnoClient}=await import(`${p.sourceRoot}/src/sdk/client.ts`);
const {computeRecall,computeNdcg,computeMrr}=await import(`${p.sourceRoot}/src/bench/metrics.ts`);
const capture=await installParentCapture(crypto.randomUUID(),p.models,`${p.root}/capture`);
const client=await createGnoClient({...init,downloadPolicy:{offline:true,allowDownload:false}});
const rows:any[]=[];const result:any={plan:p,init,rows};const save=()=>Bun.write(`${p.root}/result.json`,JSON.stringify(result,null,2));
try{
 capture.begin('index');result.index=await client.index({collection:'eval'});result.indexCapture=structuredClone(capture.finish());await save();
 for(const q of fixture){
  capture.begin(q.id);const start=performance.now();const response=await client.query(q.query,{collection:'eval',limit:10,noExpand:true,noRerank:false,graph:false,explain:true});
  const docs=response.results.map((r:any)=>r.source?.relPath??decodeURIComponent(r.uri.replace('gno://eval/','')));
  if(docs.some((d:string)=>d.startsWith('#')||d.startsWith('/')))throw Error('Invalid qrel mapping');
  rows.push({qrel:q,start,end:performance.now(),response,docs,metrics:{recallAt5:computeRecall(docs,q.relevantDocs,5),recallAt10:computeRecall(docs,q.relevantDocs,10),ndcgAt10:computeNdcg(docs,q.judgments,10),mrr:computeMrr(docs,q.relevantDocs)},capture:structuredClone(capture.finish())});await save();
 }
 result.metrics=Object.fromEntries(['recallAt5','recallAt10','ndcgAt10','mrr'].map(k=>[k,rows.reduce((n,r)=>n+r.metrics[k],0)/rows.length]));
}catch(e){result.error=String(e);process.exitCode=1;}
finally{await client.close();capture.restore();await save();}
