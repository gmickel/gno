export function nativeBytes(context: any) {
  if (typeof context?._ctx?.getMemoryBreakdown !== "function") throw Error("Native allocation counter unavailable");
  const value = context._ctx.getMemoryBreakdown();
  for (const key of ["cpuRam", "gpuVram"]) if (!Number.isSafeInteger(value[key]) || value[key] < 0) throw Error("Invalid native allocation counter");
  return value;
}
export function autoOptions(args: any[], mode: string) {
  if (mode === "sized") return args;
  if (mode !== "auto" || args.length !== 1 || typeof args[0] !== "object" || !Number.isInteger(args[0].contextSize)) throw Error("Unexpected auto control shape");
  const {contextSize, ...rest} = args[0];
  return [rest];
}
export function installModel(model: any, mode: string, emit: (v:any)=>void) {
  const ranking = model.createRankingContext;
  const context = model.createContext;
  const live = new Set<any>();
  model.createContext = async function(...args:any[]) {
    const before = await model.llama.getLlamaMemoryUsage();
    const start = performance.now();
    emit({kind:"context-start",start,arguments:args,before});
    const out = await context.apply(this,args);
    const end = performance.now();
    live.add(out);
    emit({kind:"context-created",start,end,durationMs:end-start,arguments:args,
      contextSize:out.contextSize,batchSize:out.batchSize,currentThreads:out.currentThreads,idealThreads:out.idealThreads,
      stateSize:out.stateSize,flashAttention:out.flashAttention,kvCacheKeyType:out.kvCacheKeyType,kvCacheValueType:out.kvCacheValueType,
      nativeBytes:nativeBytes(out),aggregate:await model.llama.getLlamaMemoryUsage(),before});
    const dispose = out.dispose;
    out.dispose = async function(...values:any[]) {
      const start=performance.now(); const result=await dispose.apply(this,values); live.delete(out);
      emit({kind:"context-disposed",start,end:performance.now(),aggregate:await model.llama.getLlamaMemoryUsage()});return result;
    };
    return out;
  };
  model.createRankingContext = async function(...args:any[]) {
    const effective=autoOptions(args,mode);
    emit({kind:"ranking-options",original:args,effective,mode});
    const out=await ranking.apply(this,effective);
    const rank=out.rankAndSort;
    out.rankAndSort=async function(...values:any[]) {
      const start=performance.now();
      emit({kind:"score-start",start,arguments:values,contexts:[...live].map(nativeBytes)});
      const result=await rank.apply(this,values);
      const end=performance.now();
      emit({kind:"score-end",start,end,durationMs:end-start,arguments:values,result,
        contexts:[...live].map(c=>({contextSize:c.contextSize,nativeBytes:nativeBytes(c)})),
        aggregate:await model.llama.getLlamaMemoryUsage()});
      return result;
    };
    return out;
  };
}
