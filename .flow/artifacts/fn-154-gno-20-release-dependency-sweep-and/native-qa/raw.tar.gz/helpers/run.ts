import {captureOptions} from "./launch";
const plan=await Bun.file(process.argv[2]!).json();
if(process.argv[3]!=="--native")throw Error("Explicit native opt-in required");
const source=plan.sourceRoot;
const fixture=await Bun.file(plan.fixture).json();
const spawn=Bun.spawn;let children:number[]=[];
Bun.spawn=function(options:any,...rest:any[]){
  if(!Array.isArray(options)&&options.cmd?.includes(source+"/src/llm/native-worker/entry.ts")){
    const child=spawn(captureOptions(options,source,import.meta.dir+"/child.ts",plan.childLog,plan.mode));
    children.push(child.pid);return child;
  }return Reflect.apply(spawn,Bun,[options,...rest]);
} as typeof Bun.spawn;
const {NativeWorkerClient}=await import(source+"/src/llm/native-worker/client.ts");
const {NativeRerankPort}=await import(source+"/src/llm/native-worker/ports.ts");
const uri="file:"+fixture.modelPath;
const client=new NativeWorkerClient({models:[{id:"reranker",modelUri:uri,path:fixture.modelPath,type:"rerank"}],loadTimeout:60000,inferenceTimeout:30000,warmModelTtl:300000});
const port=new NativeRerankPort(client,"reranker",uri);
const rows:any[]=[];let error:string|undefined;
try{
  for(const phase of ["cold","warm"]){
    const start=performance.now();const result=await port.rerank(fixture.input[0],fixture.input[1]);
    rows.push({phase,start,end:performance.now(),result,childPid:client.processId,generation:client.currentGeneration});
    await Bun.write(plan.output,JSON.stringify({mode:plan.mode,rows,children},null,2));
    if(!result.ok)throw Error(JSON.stringify(result.error));
  }
} catch(e){error=String(e);throw e;}
finally{
  await client.dispose();
  await Bun.write(plan.output,JSON.stringify({mode:plan.mode,rows,children,error,disposed:true},null,2));
}
