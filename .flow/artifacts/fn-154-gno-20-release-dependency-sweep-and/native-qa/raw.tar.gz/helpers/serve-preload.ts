import {mkdir} from 'node:fs/promises'; // Bun lacks directory creation.
import {installPhaseBridge} from './phase-parent';
const plan=JSON.parse(process.env.MIGRATION_QA!);
await mkdir(`${plan.root}/serve-capture`,{mode:0o700});
installPhaseBridge(plan.sourceRoot,`${plan.root}/serve-phases.jsonl`);
const {installParentCapture}=await import(`${plan.sourceRoot}/evals/acceptance/parent-capture.ts`);
await installParentCapture(crypto.randomUUID(),plan.models,`${plan.root}/serve-capture`);
