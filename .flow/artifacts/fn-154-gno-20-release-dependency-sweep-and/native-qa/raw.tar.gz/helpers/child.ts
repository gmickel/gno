import {appendFileSync} from "node:fs"; // Termination-safe sync evidence has no Bun equivalent.
import {installModel} from "./hooks";
const source=process.env.ALLOCATION_SOURCE!;
const expected=source+"/src/llm/native-worker/entry.ts";
if(process.argv[1]===expected) {
  const output=process.env.ALLOCATION_OUTPUT!, mode=process.env.ALLOCATION_MODE!;
  process.execArgv=process.execArgv.filter((v,i,a)=>v!==import.meta.path && !(v==="--preload" && a[i+1]===import.meta.path));
  let request:any=null;
  const emit=(data:any)=>appendFileSync(output,JSON.stringify({pid:process.pid,ppid:process.ppid,monotonicMs:performance.now(),request,...data},(_key,value)=>value===undefined?{$undefined:true}:value)+"\n",{mode:0o600});
  emit({kind:"child-birth",entry:process.argv[1],mode,version:Bun.version});
  const cpp=await import(Bun.resolveSync("node-llama-cpp",source+"/package.json"));
  const {ModelManager}=await import(source+"/src/llm/nodeLlamaCpp/lifecycle.ts");
  const load=ModelManager.prototype.loadModel;const seen=new WeakSet();
  ModelManager.prototype.loadModel=async function(...args:any[]){
    const start=performance.now();const result=await load.apply(this,args);const end=performance.now();
    if(result.ok&&!seen.has(result.value.model)){
      const model=result.value.model;seen.add(model);
      emit({kind:"model-loaded",start,end,arguments:args,uri:result.value.uri,backend:model.llama.gpu,
        nativeVersion:await cpp.getModuleVersion(),gpuLayers:model.gpuLayers,trainContextSize:model.trainContextSize,
        modelBytes:model._model.getMemoryBreakdown(),aggregate:await model.llama.getLlamaMemoryUsage()});
      installModel(model,mode,emit);
    }return result;
  };
  const evaluate=cpp.LlamaRankingContext.prototype._getEvaluationInput;
  cpp.LlamaRankingContext.prototype._getEvaluationInput=function(query:string,document:string){
    const result=evaluate.call(this,query,document);emit({kind:"formatted-input",query,document,tokens:[...result]});return result;
  };
  const {NativeDispatcher}=await import(source+"/src/llm/native-worker/dispatcher.ts");
  const execute=NativeDispatcher.prototype.execute;
  NativeDispatcher.prototype.execute=async function(value:any) {
    request={requestId:value.requestId,op:value.op};emit({kind:"request-start",value});
    try {const result=await execute.call(this,value);emit({kind:"request-result",result});return result;}
    catch(error){emit({kind:"request-error",error:String(error)});throw error;}
    finally{emit({kind:"request-end"});request=null;}
  };
  process.on("exit",code=>emit({kind:"child-exit",code}));
}
