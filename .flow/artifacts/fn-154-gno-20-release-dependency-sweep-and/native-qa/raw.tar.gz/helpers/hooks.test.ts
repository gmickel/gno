import {test,expect} from "bun:test";
import {autoOptions,nativeBytes,installModel} from "./hooks";
test("auto control removes only capacity; sized retains exact arguments and input is not mutated",()=>{
 const options=[{contextSize:768,batchSize:512,threads:6,flashAttention:false,custom:{same:true}}];
 expect(autoOptions(options,"sized")).toBe(options);
 expect(autoOptions(options,"auto")).toEqual([{batchSize:512,threads:6,flashAttention:false,custom:{same:true}}]);
 expect(options[0].contextSize).toBe(768);
 expect(()=>autoOptions([],"auto")).toThrow();
});
test("native counter fails closed; cannot use serialized state or estimate",()=>{
 expect(()=>nativeBytes({stateSize:3})).toThrow();
 expect(()=>nativeBytes({_ctx:{getMemoryBreakdown:()=>({cpuRam:0,gpuVram:NaN})}})).toThrow();
 expect(nativeBytes({_ctx:{getMemoryBreakdown:()=>({cpuRam:12,gpuVram:34})}})).toEqual({cpuRam:12,gpuVram:34});
});
test("observer preserves exact cold/warm scores, tokens and forwards only declared auto option; metrics refresh",async()=>{
 const events:any[]=[];let calls=0;let disposed=false;let observed:any;
 const context:any={contextSize:40960,batchSize:512,stateSize:1,_ctx:{getMemoryBreakdown:()=>({cpuRam:16,gpuVram:100+calls})},dispose:async()=>{disposed=true;}};
 const outputs=[{document:"full",score:0.123456789}];
 const model:any={llama:{getLlamaMemoryUsage:async()=>({cpuRam:16,gpuVram:100})},createContext:async function(args:any){observed=args;return context;},
  createRankingContext:async function(args:any){await this.createContext(args);return {rankAndSort:async(...values:any[])=>{expect(values).toEqual(["query",["full"]]);calls++;return outputs;}}}};
 installModel(model,"auto",event=>events.push(event));
 const rank=await model.createRankingContext({contextSize:768,threads:6});
 expect(observed).toEqual({threads:6});
 expect(await rank.rankAndSort("query",["full"])).toBe(outputs);
 expect(await rank.rankAndSort("query",["full"])).toBe(outputs);
 expect(events.filter(e=>e.kind==="score-end").map(e=>e.contexts[0].nativeBytes.gpuVram)).toEqual([101,102]);
 await context.dispose();expect(disposed).toBe(true);expect(events.at(-1).kind).toBe("context-disposed");
});

import {captureOptions} from "./launch";
test("capture selects exact frozen worker entry; preserves IPC and all launch options",()=>{
 const source="/frozen/package",entry=source+"/src/llm/native-worker/entry.ts",ipc=()=>{};
 const original={cmd:["bun","--no-env-file",entry,"{\"generation\":1}"],env:{CUDA_PATH:"/opt/cuda",GNO_OFFLINE:"1"},ipc,serialization:"advanced"};
 const other={cmd:["bun","binding-probe.js"],env:original.env};
 expect(captureOptions(other,source,"/hook","/receipt","auto")).toBe(other);
 const result=captureOptions(original,source,"/hook","/receipt","auto");
 expect(result.cmd).toEqual(["bun","--preload","/hook",...original.cmd.slice(1)]);
 expect(result.ipc).toBe(ipc);expect(result.serialization).toBe("advanced");
 expect(result.env).toEqual({...original.env,ALLOCATION_SOURCE:source,ALLOCATION_OUTPUT:"/receipt",ALLOCATION_MODE:"auto"});
 expect(original.cmd).toEqual(["bun","--no-env-file",entry,"{\"generation\":1}"]);
});
