# CUDA dependency migration preparation

Preparation only; no GPU execution, SSH, product edits, Git or Flow mutations. User subsequently restored fresh physical macOS validation: pair CUDA and Heimdall under separately declared platform policies. Final candidate package and GPU grant are prerequisites.

## Freeze requirements

Baseline source: f64c41c97e196e3bffdba23bc1c006bca7489b28, actual npm archive `/home/gordon/.cache/agent-tmp/gno-final-package-f64c41c9/pack/gmickel-gno-2.0.0.tgz`, SHA256 `56587f10c9969a795d6aa527c29fe8a057720a97d9f9e5de335daa996e706655`. Its manifest pins all 909 shipped files. Extract a new baseline package rather than mutate prior evidence.

IMPORTANT: retained f64 package node_modules links current checkout. After migration this is not a 3.19.1 baseline. Build a separately frozen old dependency closure from the f64 lockfile and verify actual resolved package versions and native binary hashes. Local Bun cache retains node-llama-cpp@3.19.1@@@1 and matching linux-x64-cuda / cuda-ext packages; cache presence alone does not prove complete dependency resolution. Never relabel a current symlink as old dependencies. Bun1.3.14 exists at `/home/gordon/.local/share/mise/installs/bun/1.3.14/bin/bun`; pin binary bytes. Candidate Bun1.4.2 path and frozen dependency closure await native_package handover.

Candidate: commit settled migration, build/pack production assets as required, provide npm archive SHA and complete shipped-file manifest, exact lockfile/package hash, Bun1.4.2 binary SHA, actual node-llama-cpp3.20.0/native binary/build provenance. No native run against changing working-tree source. Helper overlays are separate hashed development files; product bytes remain identical to selected package.

This is paired whole-release migration (source/dependency/Bun changes together), not isolated causal attribution to cpp. Cross-version native numeric drift is a finding, never rounded away; report exact deltas/order/input changes and await host decision. Do not reuse hardcoded expected cpp3.19.1 assertions for candidate or silently relax input equality.

## Minimal declared scenarios

1. Six-passage rerank: old and new, fresh owned native child per side, production sized mode only, one cold + one warm call. Preserve full query/passages, formatted tokens, raw scores, sorted ranks/indices, model hashes, actual CUDA/backend, context size/settings and actual native counters. Auto/sized comparison already completed; no reason to repeat auto for dependency smoke.
2. Matched29 hybrid + verified Ask: independent local SQLite backups of the same synthetic seed, same absolute corpus provenance, full original query/options/config and cached models. One idle hybrid + verified Ask per side; assert actual embedding/rerank/generation/judge inputs and outputs captured in selected child. Compare full vectors and full canonical response/citations/verification; only schema-defined semantic duration goes to telemetry. Original Ask abstention with one unresolved claim/one judge is a valid baseline, not a supported-answer claim. Preserve any new fallback, verdict, score or vector change.
3. Candidate idle/reload: separate explicitly pinned TTL1200ms fixture, query twice, metadata polling through3000ms, verify native child generation retired and next query reloads; compare complete next result to same-side control and record full cold cost/PID transition. Default300000 config remains the primary quality fixture; short TTL is a separate lifecycle smoke, not hidden policy change.
4. Candidate cancellation: original proven pre-aborted, queued, actual pending JS-native rerank and generation abort cases, each followed by full hybrid recovery comparator. Trigger actual iterator-pending request identity, not elapsed sleeps; record caller completion separately from dispatcher end and owner permit settlement. If no pending window occurs, mark unexercised. No artificial held native response, readonly-addon patches, or shortened model budget.

These are bounded CUDA functional migration checks, not a new performance study or full fn146 background/fairness Cartesian rerun. Lifecycle/cancel historical3.19 evidence remains available; rerunning old side lifecycle can be added only if migration result needs diagnosis.

## Existing exact substrate

Rerank helper root `/home/gordon/.cache/agent-tmp/gno-fn145-native-allocation-cuda-44cf2a1d`: run.ts, launch.ts, child.ts, hooks.ts, hooks.test.ts, fixture.json, supervise.py and analysis. It selects native-worker/entry.ts and wraps actual ModelManager/context/ranking calls inside child. Fixture holds all six original prepared passages, model SHA `22c9979ce4fbcdc5acdc310c6641c32797eff1aa980b8f7a2db8a8ea23429a48`, cache file `/home/gordon/.cache/gno/models/hf_ggml-org_qwen3-reranker-0.6b-q8_0.gguf`. Original capture SHA `504fcb9fc5784f02836f1165d0436d27526fd4721335fd23b928e994f8df9ffc`. Reuse inputs unchanged. Supervisor's historical protected PIDs must be replaced by a newly observed/pinned live inventory; do not assume stale PID identity.

Matched29/native cancellation root `/home/gordon/.cache/agent-tmp/gno-fn146-native-cancellation-js-evaluate`: init.json, fixture.json, preflight.json, phase-parent.ts, phase-child.ts, iterator-observer.ts, ownership-observer.ts, iterator-preflight.ts, run.ts, supervise.py. This original runner has hardcoded source/root; copy into new scratch and bind selected package/independent seed backup. Its original product was a30, so select f64 baseline package explicitly. Canonical helper8b45 retained at `/home/gordon/.cache/agent-tmp/gno-fn146-native-cancellation-context-fixed/freeze/helper8b45` and archive `/home/gordon/.cache/agent-tmp/gno-final-package-f64c41c9/helpers-8b45a54d.tar`.

Corpus `/home/gordon/.cache/agent-tmp/gno-fn144-packed-surfaces-98252a9c/ask29/corpus/probe`; original manifest sibling `original-manifest.json`. Query `Who owns the meadow migration?`, collection probe, limit3, noExpand true, noRerank false, graph false; original explain flag retained where declared. Config in init.json includes exact cached embed/rerank/expand/gen URIs, default300000 TTL and original budgets. Model pins in fixture.json: embedding `06507c7b42688469c4e7298b0a1e16deff06caf291cf0a5b278c308249c3e439`; generationQwen1.7B `b139949c5bd74937ad8ed8c8cf3d9ffb1e99c866c823204dc42c0d91fa181897`; expansion `3b20c99404c2c1d66ad695489bf91cf5b5d3369e8055d5587fc60507ceac3338`. No new model selection.

Final public/Ask comparator and corrected source-backed seed preparation: `notes/fn146.5-{configure,run,compare,supervise,surface-preload,wire}.ts` (supervisor is .py), plus dispatch/phase helper siblings. Authoritative successful evidence `.flow/artifacts/fn-146-cancellation-and-bounded-background/final-native-cuda/`; final package overlay `/home/gordon/.cache/agent-tmp/fn1465-final-f64c41c9/package`. Do not run stale notes/fn146.5-run-config.json unchanged: it pins prior source/root and a complete heavy scenario. Reuse narrowed scratch SDK flow and existing comparator, preserving raw responses and actual child captures.

Idle REST prior `/home/gordon/.cache/agent-tmp/gno-fn144-resident/cuda-23ba2c25/run.py` demonstrates metadata polls + TTL reload, but its noRerank true and older corpus differ. Reuse orchestration only; current migration lifecycle must use declared matched29 CUDA noRerank false fixture.

## Commands after binding (not run)

CPU binding/preflight must first prove selected cpp3.20 symbols and synchronous/asynchronous iterator forwarding remain compatible without loading models. Validate `LlamaContextSequence.prototype.evaluate`, `_getEvaluationInput`, ModelManager.loadModel and selected child entry; hashes recorded. Do not assume canonical8b45 hook compatibility with3.20. Each side receives identical observation semantics or comparison is incomplete.

```
OLD_BUN=/home/gordon/.local/share/mise/installs/bun/1.3.14/bin/bun
"$OLD_BUN" test OLD_SCRATCH/hooks.test.ts
NEW_BUN test NEW_SCRATCH/hooks.test.ts
OLD_BUN --no-env-file OLD_SCRATCH/iterator-preflight.ts
NEW_BUN --no-env-file NEW_SCRATCH/iterator-preflight.ts
python3 OLD_SCRATCH/supervise.py sized
python3 NEW_SCRATCH/supervise.py sized
```

`OLD_SCRATCH`, `NEW_SCRATCH`, `NEW_BUN` are intentionally unresolved until package handover; sourceRoot, fixture, childLog, output and runtime binary must be frozen in each plan. Existing allocation supervisor needs runtime-path binding; do not invoke its inherited PATH Bun. Subsequent SDK lifecycle/cancel driver adaptation remains scratch work, with a single explicit --native entry and per-phase watchdog. No runnable-ready claim before those bindings and CPU preflight pass.

Safety: native build never/download disabled, CUDA_PATH=/opt/cuda, child-only HOME/XDG isolation; one model-owning process group at a time, verify all descendant birth identities absent before next phase. Reuse conservative admission12GiB free GPU +12GiB MemAvailable,180s per phase,8192MiB owned GPU and8192MiB owned RSS, retain full stdout/stderr/actual native capture/resources. Stop first native fatal/safety failure; any justified harness correction gets a new immutable revision. No unrelated live process/config/index touched. Fresh Heimdall Metal validation is now authorized after final freeze and GPU grant; no Ivan run.

## Updated setup

Local baseline extraction: `/home/gordon/.cache/agent-tmp/gno-dependency-migration-cuda-preparation/baseline/source`; f64 bun.lock verified against exact git show. Fresh isolated dependency cache and frozen install initiated; receipt pending. Heimdall baseline: `/private/tmp/gno-dependency-migration-f64.gaNIPy/baseline`; candidate reserved sibling `/candidate`; independent install-cache. No GPU inference launched. Final scope also includes bounded owned-process shutdown on both platforms.

Baseline installation complete on both hosts. Root lefthook prepare failed without Git metadata (both original and LEFTHOOK=0 attempts retained); frozen --ignore-scripts pass finalized populated dependencies. No model inference. Local exact npm package `/home/gordon/.cache/agent-tmp/gno-dependency-migration-cuda-preparation/baseline/package`, independent dependency closure under sibling source/node_modules. Heimdall exact package `/private/tmp/gno-dependency-migration-f64.gaNIPy/package`, independent closure under baseline/node_modules. All909 shipped package bytes verified on both; source archive does not include npm-generated extension assets, so use the verified npm package for physical QA. Actual cpp3.19.1, CUDA native SHA70e62254f49e75c723bc44332324533204d29d64f8a73062be125c1765452102, Metal native SHAa6c773be6050823293ae46f097e2c72c97452db64ff92a7fde58d6ffb9b96acd.
