import pathlib, shutil, json, hashlib
root=pathlib.Path(__file__).resolve().parent
helpers=root/'helpers';helpers.mkdir(exist_ok=True)
allocation=pathlib.Path('/home/gordon/.cache/agent-tmp/gno-fn145-native-allocation-cuda-44cf2a1d')
phase=pathlib.Path('/home/gordon/.cache/agent-tmp/gno-fn146-native-cancellation-js-evaluate')
for n in ['run.ts','child.ts','launch.ts','hooks.ts','hooks.test.ts','fixture.json']:
 shutil.copy2(allocation/n,helpers/n)
for n in ['phase-parent.ts','phase-child.ts','iterator-observer.ts','ownership-observer.ts']:
 shutil.copy2(phase/n,helpers/n)
script=(phase/'iterator-preflight.ts').read_text().replace('const source=`${import.meta.dir}/freeze/accepted-package/package`;','const source=process.argv[2]!;')
(helpers/'iterator-preflight.ts').write_text(script)
fixture=json.loads((phase/'fixture.json').read_text());(helpers/'sdk-fixture.json').write_text(json.dumps(fixture,indent=2))
init=json.loads((phase/'init.json').read_text());(helpers/'sdk-init.json').write_text(json.dumps(init,indent=2))
for platform in ['cuda','metal']:
 for side in ['baseline','candidate']:
  remote='/private/tmp/gno-dependency-migration-f64.gaNIPy'
  base=str(root) if platform=='cuda' else remote
  source=f'{base}/{side}/package' if platform=='cuda' or side=='candidate' else f'{base}/package'
  bun=('/home/gordon/.local/share/mise/installs/bun/1.3.14/bin/bun' if side=='baseline' else '/home/gordon/.bun/install/cache/@oven/bun-linux-x64@1.4.2@@@1/bin/bun') if platform=='cuda' else ('/Users/gordon/.local/share/mise/installs/bun/1.3.14/bin/bun' if side=='baseline' else remote+'/candidate/tools/package/bin/bun')
  model='/home/gordon/.cache/gno/models/hf_ggml-org_qwen3-reranker-0.6b-q8_0.gguf' if platform=='cuda' else '/Users/gordon/Library/Caches/gno/models/hf_ggml-org_qwen3-reranker-0.6b-q8_0.gguf'
  config={'platform':platform,'side':side,'sourceRoot':source,'bun':bun,'cppVersion':'3.19.1' if side=='baseline' else '3.20.0','root':f'{base}/runs/{side}-rerank-v1','helperRoot':f'{base}/helpers','mode':'sized','modelPath':model,'wallSeconds':180,'rssMiB':8192,'gpuMiB':8192,'admissionFreeMiB':12288,'modelSha256':'22c9979ce4fbcdc5acdc310c6641c32797eff1aa980b8f7a2db8a8ea23429a48'}
  (root/f'{platform}-{side}-rerank.json').write_text(json.dumps(config,indent=2))
(helpers/'pins.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in helpers.iterdir() if p.is_file() and p.name!='pins.json'},indent=2))
