import pathlib,json,hashlib,gzip,tarfile,io
root=pathlib.Path(__file__).resolve().parent
target=pathlib.Path('/home/gordon/work/gno/.flow/artifacts/fn-154-gno-20-release-dependency-sweep-and/native-qa')
target.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
selected=set(p for p in root.iterdir() if p.is_file() and p.suffix in ['.json','.ts','.py','.md','.log'])
for name in ['helpers','helper-revisions','corpus','qrels-corpus','runs','metal-raw']:
 for p in (root/name).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.jsonl','.log','.ts','.py','.md'] and not any(x in p.parts for x in ['node_modules','isolation']):selected.add(p)
for name in ['baseline','candidate']:
 for p in (root/name).iterdir():
  if p.is_file() and p.suffix in ['.json','.log']:selected.add(p)
 for file in ['bun.lock','package.json']:selected.add(root/name/'source'/file)
selected.add(root/'tools/bun-darwin142-receipt.json')
inventory=[]
with (target/'raw.tar.gz').open('wb') as file:
 with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as archive:
   for path in sorted(selected):
    raw=path.read_bytes();name=str(path.relative_to(root));info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;info.mtime=0
    archive.addfile(info,io.BytesIO(raw));inventory.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
archive=(target/'raw.tar.gz').read_bytes()
(target/'inventory.json').write_text(json.dumps({'archive':'raw.tar.gz','archiveBytes':len(archive),'archiveSha256':sha(archive),'files':inventory},indent=2)+'\n')
for name in ['analysis.json','rerank-analysis.json','cancel-settlement.json','attempts.json','qrels-preflight.json']:(target/name).write_bytes((root/name).read_bytes())
with tarfile.open(target/'raw.tar.gz','r:gz') as archive:
 for row in inventory:
  data=archive.extractfile(row['path']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
(target/'README.md').write_text('''# Frozen dependency migration: physical CUDA and Heimdall

Functional evidence ready for host acceptance. This is not bit-identical CUDA retrieval: full floating-point, ranking, internal generated claim and capsule changes remain explicit. No per-query labelled quality metric regressed. No release verdict is inferred by this worker.

## Pinned source, runtimes and inputs

Old: f64c41c97e196e3bffdba23bc1c006bca7489b28, GNO2.0.0 npm archive SHA25656587f10c9969a795d6aa527c29fe8a057720a97d9f9e5de335daa996e706655, Bun1.3.14, node-llama-cpp3.19.1. Candidate:64400ffeffa59ddb58dfd10f1e6386a7eb81f6a6, npm archive SHA25694581ea58f100a6d1e50c311d14addb158b0defa3771e87aace603df4f52e224, Bun1.4.2, cpp3.20.0. All909/1011 shipped files verified after physical execution on both hosts. Independent old/new frozen-lock dependency closures; no dependency symlink to changing development checkout. Detailed JS/native library/Bun hashes in baseline-final-pins.json/candidate-final-pins.json and Metal equivalents. Canonical child capture helpers8b45 are development overlays; all shipped product bytes unchanged.

CUDA host uses existing local hardware; Heimdall is Apple M4 Max128GiB, Darwin arm64, distinct from prior Ivan. Exact cached Qwen0.6B embedding model SHA06507c7b42688469c4e7298b0a1e16deff06caf291cf0a5b278c308249c3e439 and Qwen1.7B Q4 generation SHAb139949c5bd74937ad8ed8c8cf3d9ffb1e99c866c823204dc42c0d91fa181897 copied to Heimdall QA-local cache, verified by canonical child capture. RerankerQwen0.6B Q8 SHA22c9979ce4fbcdc5acdc310c6641c32797eff1aa980b8f7a2db8a8ea23429a48 unchanged. No model download or live cache replacement. Every fixture/model URI/hash/config in the full raw archive.

Original six prepared rerank passages retained byte-for-byte. Source-backed synthetic ownership corpus contains30 Markdown files and is physically shared between independent old/new indexes on each host; query Who owns the meadow migration?, limit3, collectionprobe, noExpandtrue, noRerankfalse, graphfalse, original context/generation budgets. Each host builds its own indexes. No cross-host index is used for inference. Extended CUDA corpus is the existing9 documents and29 qrels from evals/fixtures, with unchanged relevance labels/hash receipts. No new golden or threshold.

## Observed comparisons

Heimdall: exact old/new six prepared inputs, native token streams, scores and ranks; exact native embedding/rerank/Ask inputs and outputs; full canonical vsearch/query/verified Ask response equality. Verified Ask abstains with one unresolved claim and one actual judge call on each side.

CUDA: six prepared inputs/tokens exact, but scores and ranks change. Old input-index order0,5,2,1,4,3; new0,1,5,2,4,3. All six passages express the same labelled ownership fact. Fresh-index vsearch/hybrid top3 membership unchanged but ordering/scores change. Verified Ask public abstention and verdict unchanged with one judge each; internal generated claim paraphrases, evidence retrievalRank1→2, associated capsule/claim/verifier IDs differ. These fields are preserved, not projected away. Only canonical verification.semantic.durationMs is telemetry. Full raw vectors and native generation outputs retained.

CUDA29 relevance cases: Recall@5=1,Recall@10=1,MRR=1 on both releases. First-occurrence unique-document nDCG@10=0.9958508952205714 on both. For every metric individually:29unchanged,0regressed,0improved,min/maxdelta0. The unmodified existing metric over passage results returns nDCG1.2743801303124414 on both because repeated document URIs accrue gain more than once. That raw metric remains in evidence; the separately labelled first-occurrence document projection preserves order and calls the same existing metric functions, without changing qrels. All29 actual native responses/captures retained. This is a small fixture gate, not exhaustive retrieval equivalence.

Candidate lifecycle, both hosts: separate explicitly pinned1200msTTL; initial/warmquery,3000msmetadata polls, child retires, next query loads generation2. Full response/native input/output equal before/after. Default300000ms remains primary quality config. Actual pre-aborted/queued/active-rerank/active-generation cancellation; all four subsequent hybrid recoveries fullresponse/nativeIO exact. Actual JS evaluation pending IDs observed, native dispatcher settles after abort: CUDA rerank483ms/generation29ms; Metal1256ms/211ms. Caller cancellation and native settlement remain distinct; no fake held-native delays.

Actual packaged CLI serve SIGTERM during pending native evaluation: CUDA456.13ms,Metal99.31ms,exit0; complete owned descendant absence. This demonstrates graceful in-flight shutdown, not a stuck kernel/forced-kill branch. No full background/fairness rerun requested for this migration.

## Timing and safety

Single ordered pairs only. CUDA rerank native scoring old343.77/110.68ms vsnew351.57/111.95ms (cold/warm); Metal345.78/269.35 vs506.61/274.11ms. Slower samples retained. First new Metal wholeprocess10.71s vsold1.74s includes initialization and observation overhead. No throughput or p99 claim.

Each isolated phase:180seconds,8192MiB ownedRSS, CUDA8192MiB ownedGPU; admission12GiB freeGPU and12GiB MemAvailable. Heimdall independently declared128GiBminimum, kernelpressure-free>=50%, pressure1admission/throughout, immediatewarningstop. Native memory safety checks unchanged. Owned process groups only; full PID/birth/resource and absence receipts. All19 supervised attempts ended with owned processes absent; no pressure/resource stops. No unrelated live process, service, config or index mutated. Both GPU slots released.

## Retained failures and scope

19 attempts:16 completed functional phases, plus3 negative fixtures. CUDA baselinequalityv1 used index.sqlite, whose inferred indexName=index caused verifiedAsk default-index rejection; v2 uses index-default.sqlite. Metal baselinequalityv1 rejected mismatched bytes behind an existing embedding filename before native load; v2 uses exact QA-local copied embedding model. CUDA shutdownv2 sent unsupported public REST showSources and received400, so only idle shutdown occurred; v3 uses the supported request schema and observes active-native SIGTERM. Each negative keeps full outputs/resources. Earlier install failures are retained: archive root lefthook prepare requires Git metadata; frozen ignore-scripts install finalized populated closure; Bun1.3.14 cannot parse candidate lockfileVersion2, corrected installation uses1.4.2. No product patch or weakened native gate. Exact failed helper bytes reconstructed and hash-checked against recorded run preflight receipts, included under helper-revisions.

## Reproduce and verify

Local scratch `/home/gordon/.cache/agent-tmp/gno-dependency-migration-cuda-preparation`; Heimdall `/private/tmp/gno-dependency-migration-f64.gaNIPy`. Each captured process-receipt contains full actual command, runtime/helper/model/config hashes, admission and cleanup. `helpers/supervise.py CONFIG --native` refuses a used output root. Configs cuda/metal-side-rerank,side-quality,candidate-idle,candidate-cancel,candidate-shutdown pin each phase. Qrels configs CUDA only. For a new run prepare new output roots and local independent indexes, retain physical corpus provenance, same inputs/models/budgets, verify exact source/dependency/runtime pins, run CPU hooks/iterator forwarding preflights, then serialize owned phases. Do not invoke old paths over existing evidence. Source/npm/model/native binary archives are not included.

`raw.tar.gz` contains complete selected textual raw receipts, logs, captures, models/input/config/source hashes, helpers, failed revisions, corpus/qrels and runtime install logs. No SQLite/database, model, executable, dependency cache or private vault payload is included. `inventory.json` records every original file length/SHA and full compressed archive length/SHA. Gzip mtime0; no truncated vectors/rows. `analyze.ts` reproduces analysis from retained raw; it imports the pinned candidate src/bench/metrics.ts. Supplemental cancel-settlement and attempts are directly traceable to phase logs/process receipts. SHA256SUMS covers every artifact except itself.
''')
(target/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(target.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({'target':str(target),'files':len(list(target.iterdir())),'bytes':sum(p.stat().st_size for p in target.iterdir()),'rawFiles':len(inventory),'rawArchiveSha256':sha((target/'raw.tar.gz').read_bytes()),'checksumSha256':sha((target/'SHA256SUMS').read_bytes())}))
