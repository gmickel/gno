import {Database} from 'bun:sqlite';
import {readFileSync} from 'node:fs'; // Synchronous observational phase log.
const plan=await Bun.file(process.argv[2]!).json();
if(process.argv[3]!=='--native'||process.env.GNO_QA_SUPERVISED!=='1')throw Error('Supervisor required');
const init=await Bun.file(plan.initPath).json(),root=plan.root;
const db=new Database(plan.dbPath,{readonly:true});await Bun.write(`${root}/data/index-default.sqlite`,db.serialize());db.close();
await Bun.write(`${root}/config.json`,JSON.stringify(init.config));
const reservation=Bun.serve({hostname:'127.0.0.1',port:0,fetch:()=>new Response('owned')});const port=reservation.port;reservation.stop(true);
const command=[plan.bun,'--no-env-file','--preload',`${plan.helperRoot}/serve-preload.ts`,`${plan.sourceRoot}/src/index.ts`,'--config',`${root}/config.json`,'--index','default','serve','--host','127.0.0.1','--port',String(port)];
const processChild=Bun.spawn(command,{cwd:plan.sourceRoot,env:{...process.env,GNO_DATA_DIR:`${root}/data`,GNO_CACHE_DIR:`${root}/cache`,MIGRATION_QA:JSON.stringify(plan)},stdin:'ignore',stdout:Bun.file(`${root}/serve.stdout.log`),stderr:Bun.file(`${root}/serve.stderr.log`)});
const result:any={command,parentPid:processChild.pid};const save=()=>Bun.write(`${root}/result.json`,JSON.stringify(result,null,2));
const poll=async(fn:()=>Promise<boolean>|boolean,ms:number)=>{const end=performance.now()+ms;while(performance.now()<end){if(await fn())return true;await Bun.sleep(2);}return false;};
try{
 if(!await poll(async()=>{if(processChild.exitCode!==null)throw Error('Server exited');try{return(await fetch(`http://127.0.0.1:${port}/api/health`)).ok;}catch{return false;}},15000))throw Error('Readiness timeout');
 const request={query:'Who owns the meadow migration?',collection:'probe',limit:3,noExpand:true,noRerank:false,graph:false};
 result.control=await(await fetch(`http://127.0.0.1:${port}/api/query`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)})).json();
 const at=Date.now();let done=false;const controller=new AbortController();const inflight=fetch(`http://127.0.0.1:${port}/api/ask`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...request,verify:true,showSources:true}),signal:controller.signal}).then(async r=>({status:r.status,body:await r.text()})).catch(e=>({error:String(e)})).finally(()=>done=true);
 const pending=()=>{let rows:any[];try{rows=readFileSync(`${root}/serve-phases.jsonl`,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);}catch{return;}return rows.findLast(r=>r.at>=at&&r.event.kind==='evaluation-pending'&&!rows.some(e=>e.pid===r.pid&&e.event.id===r.event.id&&e.event.evaluationId===r.event.evaluationId&&['evaluation-end','evaluation-error'].includes(e.event.kind)));};
 await poll(()=>Boolean(pending())||done,30000);result.phaseAtSignal=pending();result.actualNativeActive=Boolean(result.phaseAtSignal&&!done);const start=performance.now();processChild.kill('SIGTERM');result.signalAt=Date.now();
 const exited=await Promise.race([processChild.exited.then(code=>({code})),Bun.sleep(11000).then(()=>({timeout:true}))]);result.shutdownMs=performance.now()-start;result.exit=exited;controller.abort();result.caller=await inflight;
 if('timeout' in exited)throw Error('Shared11s shutdown bound exceeded');
}catch(e){result.error=String(e);process.exitCode=1;}
finally{if(processChild.exitCode===null){processChild.kill('SIGTERM');await Promise.race([processChild.exited,Bun.sleep(1000)]);if(processChild.exitCode===null)processChild.kill('SIGKILL');await processChild.exited;}await save();}
