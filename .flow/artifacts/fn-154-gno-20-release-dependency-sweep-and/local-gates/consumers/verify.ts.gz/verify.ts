import assert from "node:assert/strict";
import { join } from "node:path";

const consumer = process.argv[2]!;
const root = join(consumer, "node_modules/@gmickel/gno");
const vendor = join(root, "vendor/converters");
const manifest = await Bun.file(join(vendor, "upstream-manifest.json")).json();
let checked = 0;
for (const pkg of manifest.packages) {
  for (const [path, hash] of Object.entries(pkg.files)) {
    const bytes = await Bun.file(join(vendor, pkg.name, path)).bytes();
    assert.equal(new Bun.CryptoHasher("sha256").update(bytes).digest("hex"), hash);
    checked++;
  }
}
assert.equal(checked, 99);
const resolved: Record<string, unknown> = {};
for (const [name, dependency, expected] of [
  ["markitdown-ts", "xlsx", "0.20.3"],
  ["officeparser", "pdfjs-dist", "6.3.289"],
]) {
  const path = Bun.resolveSync(`${dependency}/package.json`, join(vendor, name));
  const pkg = await Bun.file(path).json();
  assert.equal(pkg.version, expected);
  resolved[dependency] = { path, version: pkg.version };
}
const notices = await Bun.file(join(root, "THIRD_PARTY_NOTICES.md")).text();
for (const text of ["markitdown-ts 0.0.10", "officeparser 7.8.0", "SheetJS 0.20.3", "PDF.js 6.3.289"]) assert.ok(notices.includes(text));
const { markitdownAdapter } = await import(join(root, "src/converters/adapters/markitdownTs/adapter.ts"));
const { officeparserAdapter } = await import(join(root, "src/converters/adapters/officeparser/adapter.ts"));
const { DEFAULT_LIMITS } = await import(join(root, "src/converters/types.ts"));
const conversions = [];
for (const [extension, adapter, claims] of [
  ["xlsx", markitdownAdapter, ["Widget", "Gadget"]],
  ["pptx", officeparserAdapter, ["GNO Test Presentation", "speaker notes"]],
  ["pdf", markitdownAdapter, ["GNO Test Document", "quick brown fox"]],
] as const) {
  const sourcePath = `/home/gordon/work/gno/test/fixtures/conversion/${extension}/sample.${extension}`;
  const bytes = await Bun.file(sourcePath).bytes();
  const result = await adapter.convert({ sourcePath, relativePath: `sample.${extension}`, collection: "package-proof", bytes, ext: `.${extension}`, mime: extension === "pdf" ? "application/pdf" : "application/octet-stream", limits: DEFAULT_LIMITS });
  assert.equal(result.ok, true, JSON.stringify(result));
  for (const text of claims) assert.ok(result.value.markdown.includes(text), text);
  conversions.push({ extension, converterId: result.value.meta.converterId, converterVersion: result.value.meta.converterVersion });
}
console.log(JSON.stringify({ bun: Bun.version, root, upstreamFilesVerified: checked, resolved, thirdPartyNotices: true, conversions }, null, 2));
