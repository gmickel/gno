import { strict as assert } from "node:assert";
import { createServer } from "/home/gordon/work/gno/node_modules/evalite/dist/server.js";
import { InMemoryStorage } from "/home/gordon/work/gno/node_modules/evalite/dist/storage/in-memory.js";
import { createEvaliteFileIfNeeded } from "/home/gordon/work/gno/node_modules/evalite/dist/internal-utils.js";

const fetch = (input: string | URL) => globalThis.fetch(input, {headers: {connection: "close"}});
const root = import.meta.dir;
const reservation = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: () => new Response() });
const port = reservation.port!;
await reservation.stop(true);
const storage = InMemoryStorage.create();
const server = createServer({ storage });
let socket: WebSocket | undefined;
const report: Record<string, unknown> = { port, pid: process.pid };
try {
  server.start(port); console.log("started",port);
  const base = `http://localhost:${port}`;
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    try { const r = await fetch(`${base}/api/server-state`); if (r.ok) { await r.arrayBuffer(); ready = true; break; } } catch {}
    await Bun.sleep(20);
  }
  console.log("ready",ready); assert(ready, "server readiness");
  const page = await fetch(base);
  assert.equal(page.status, 200);
  const html = await page.text();
  assert(html.includes("<html"));
  await Bun.write(`${root}/index.html`, html);
  const asset = html.match(/(?:src|href)="([^\"]+\.(?:js|css))"/)?.[1];
  assert(asset, "built static asset exists");
  const assetResponse = await fetch(new URL(asset, base));
  assert.equal(assetResponse.status, 200);
  const assetBytes = await assetResponse.bytes();
  assert(assetBytes.length > 0);
  report.asset = { path: asset, bytes: assetBytes.length, type: assetResponse.headers.get("content-type") };
  const state = await (await fetch(`${base}/api/server-state`)).json();
  assert.equal(state.type, "idle");
  const menu = await (await fetch(`${base}/api/menu-items`)).json();
  assert.deepEqual(menu, { suites: [], score: 0, runStatus: "success" });
  report.initialState = state;
  report.menu = menu;
  console.log("http complete"); socket = new WebSocket(`ws://localhost:${port}/api/socket`);
  await Promise.race([new Promise<void>((resolve, reject) => { socket!.onopen = () => resolve(); socket!.onerror = reject; }), Bun.sleep(3000).then(() => { throw new Error("websocket open deadline"); })]);
  console.log("ws open"); const update = { type: "idle" as const, cacheHitsByEval: { 1: 2 }, cacheHitsByScorer: {} };
  const received = new Promise<unknown>((resolve, reject) => { socket!.onmessage = event => resolve(JSON.parse(String(event.data))); socket!.onerror = reject; });
  server.updateState(update);
  assert.deepEqual(await Promise.race([received, Bun.sleep(3000).then(() => { throw new Error("websocket update deadline"); })]), update);
  assert.deepEqual(await (await fetch(`${base}/api/server-state`)).json(), update);
  report.websocketUpdate = update;
  console.log("ws updated"); const png = Uint8Array.from(Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aC1kAAAAASUVORK5CYII=", "base64"));
  const file = await createEvaliteFileIfNeeded({ input: png, rootDir: `${root}/files` });
  assert.equal(file.__EvaliteFile, true);
  assert(file.path.endsWith(".png"));
  assert.deepEqual(await Bun.file(file.path).bytes(), png);
  await assert.rejects(createEvaliteFileIfNeeded({ input: new TextEncoder().encode("unknown arbitrary bytes cannot be an image"), rootDir: `${root}/files` }), /Cannot determine file type/);
  report.png = { path: file.path, bytes: png.length };
  report.unknownBytesRejected = true;
} finally { console.log("closing",JSON.stringify(report));
  if (socket) { const closed = new Promise<void>(resolve => { socket!.onclose = () => resolve(); }); socket.close(); await Promise.race([closed, Bun.sleep(1000)]); }
  await server.stop(); console.log("server closed");
  await storage.close();
}
try { await fetch(`http://localhost:${port}/api/server-state`); throw new Error("listener survived cleanup"); } catch (error) { if (error instanceof Error && error.message === "listener survived cleanup") throw error; }
report.listenerClosed = true;
await Bun.write(`${root}/results.json`, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify(report));
