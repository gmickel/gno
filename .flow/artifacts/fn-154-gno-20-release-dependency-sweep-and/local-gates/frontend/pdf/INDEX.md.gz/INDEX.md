# fn-112 task .6 PDF viewer smoke — artifact index

- Started: 2026-09-05T11:18:51.310Z
- Finished: 2026-09-05T11:20:22.678Z
- Platform: linux/x64 Bun 1.4.2
- Failures: 0

## Screenshots
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/CLEAN__viewer-links-rendered.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/CLEAN__standard-font.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/CLEAN__cjk-cmap.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/CLEAN__js-action.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-loading.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-progressive.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-empty.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-corrupt.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-password.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-network.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__state-bootstrap.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__align-100.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__align-fit-width.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__align-200.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-dark-w1380-rail.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-dark-w1380-overview.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-dark-w900-rail.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-dark-w900-overview.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-light-w1380-rail.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-light-w1380-overview.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-light-w900-rail.png`
- `/home/gordon/.cache/agent-tmp/fn154-frontend-qa/pdf/INTERCEPTION__visual-light-w900-overview.png`

## Modes
- CLEAN: {"name":"CLEAN","ok":true}
- INTERCEPTION: {"name":"INTERCEPTION","ok":true}

## Artifact hashes (sha256)
- `CLEAN__viewer-links-rendered.png`: `3883002716d2e465ac485cfa856979398b76de4c6f8a41073dcad3d947fdfdcb`
- `CLEAN__standard-font.png`: `c5e29be2a62c6ada36b941c5c5cf285e2d69891b3aa0255c574c3a5a4b0c30e0`
- `CLEAN__cjk-cmap.png`: `1e2199bede415fc0bb36a7565ccbfaa4e00a5e7a4cdc44657dc02518c5538590`
- `CLEAN__js-action.png`: `424a9b4378975253c47346cdcfbc441c75693e3c12910f19827865f62395dc83`
- `INTERCEPTION__state-loading.png`: `0d0cc49d8e4a8738d9944d56b0e35471da1441a55d97fad0e701ffd5a19a0481`
- `INTERCEPTION__state-progressive.png`: `0a7599e82dfcbdf230b189b8d11164b88b41dbd089123bb1b0b571b73a0589be`
- `progressive-control-log.json`: `759082b0659cbfcb590abe169ed6211b6c36814aae528935e5472308b76f14ad`
- `INTERCEPTION__state-empty.png`: `a864afa65355ee0216691c067186104767d02215207d39a2350aa9431262242d`
- `INTERCEPTION__state-corrupt.png`: `dfd55e1d130fa0dfd5a5224dc9e9f6617ec15c74436be0cbdcafbed53f1fee02`
- `INTERCEPTION__state-password.png`: `3b554fd1f5522ac730c60fdd2e3db7da965de5ed72bf83d7a498111f4c96d8bb`
- `INTERCEPTION__state-network.png`: `f170ce15a2958be74ba3497b0b7aa712277c4f1c05d28245a08d9976246c8641`
- `INTERCEPTION__state-bootstrap.png`: `bac2c56df399bbd644ce77231f2560715829d204aeedaf7147aa7cce6f033b62`
- `INTERCEPTION__align-100.png`: `8438911a37cb2c4df8c9b4218a30f87490b47b38f734b6cb73eba288710df1a5`
- `INTERCEPTION__align-fit-width.png`: `7ddb727259bcc2e5a5d8064f84d302fa8ae71d71e3fc4928671a4ad08c3a0548`
- `INTERCEPTION__align-200.png`: `8c560d1a44e4490100e767558e93f9687c19d918796de2177789d6f54124e104`
- `p3-metrics.json`: `6bd2500ee139db2fa4f45283b53f4d3e697b24b40eeaa3788fb7a2d69a05e0ed`
- `p4a-samples.json`: `77c7633342bdac2418a80b039406377dbc6c2f83965b906da484765a5e4f9e9e`
- `p4a-metrics.json`: `8206988969deb9f482410375c895d1667021ed542c41220c3d30380d3c6c5130`
- `p4b-ladder.json`: `f657654e8d8afaebde8ebc488f97d4e6d7d82256f29adc38f02dab04119a2347`
- `p4b-events.json`: `d20f6516d0ef0f0d788d5c7cf9abe81745febff20cffa3513b87317506ad7c42`
- `p5-metrics.json`: `37955ec4aac0d7681d4a54a0babe8bffcad50ea66cb270449ff761eb4295974a`
- `p6-metrics.json`: `9ea40672b51b230173a8c4cec92c017e1e201357f4d4d98e32951d9e63a1791f`
- `INTERCEPTION__visual-dark-w1380-rail.png`: `60bd51127392aa9a385b683caeaca32b58f20de71eb3a65a7f0e8e61cd5f6571`
- `INTERCEPTION__visual-dark-w1380-overview.png`: `de2bc63bb59a1f81849170ab155d91f8bcf26d1b63791e347e0c19fdc9e33758`
- `INTERCEPTION__visual-dark-w900-rail.png`: `6eb2989be4dffcca284b5c73a282417d348737b67a5ac4bb8d87165705b9f1e4`
- `INTERCEPTION__visual-dark-w900-overview.png`: `6e81138cd567b1208b0feac00bbc8b8fa5dedb488e9ad05469b6470095781bb9`
- `INTERCEPTION__visual-light-w1380-rail.png`: `adb7b901dc18f3d619b4d78ddb4751294199df988c2803eb709d4ec74f271c2a`
- `INTERCEPTION__visual-light-w1380-overview.png`: `ec792616b891e630e294cb0abe98933aa29b3d5d59fc00193b06609aaf2866a9`
- `INTERCEPTION__visual-light-w900-rail.png`: `3597afc023108ce90c6a5730c0c01d8bbbb84ff12e1ba079da4461f6697fe7bc`
- `INTERCEPTION__visual-light-w900-overview.png`: `24d0895014105f60c58b3fb1df169698131de30f901fdb5964e0cdc0a0b5f2af`
- `visual-theme-proof.json`: `3cb2b91d2d6dd397507c2fa8d1ef2b2148377ffd329d94c1802d0b9b9bdd4365`
- `server-stdout.log`: `1dd66d6c41daaab448bae2460ba01095f99a11254a5012d13af37a568be65c1e`
- `server-stderr.log`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- `request-log.json`: `1734570da76d73e77313b370b0348b7c898dfbd3e68e4f1ceb8d6a5a72fd7604`
- `console-log.json`: `ebdda25820b4f712db161578ae54d8feef8a94e104734cc8113fe343c182439c`
- `evidence.json`: `48303a0040049213aff57eff57dc9168c23866ec82d4257338d2f975a097c8b5`

## Failures
- (none)
