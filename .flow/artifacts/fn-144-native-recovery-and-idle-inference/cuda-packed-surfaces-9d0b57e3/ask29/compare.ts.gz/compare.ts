import {compareAcceptance} from '../package/evals/acceptance/compare.ts';
import {canonicalJson} from '../package/evals/agentic/canonical.ts';
const root=import.meta.dir;
const read=async(role:string)=>({plan:await Bun.file(`${root}/${role}/plan.json`).json(),result:JSON.parse(new TextDecoder().decode(Bun.gunzipSync(await Bun.file(`${root}/${role}/evidence/result.json.gz`).bytes())))});
const a=await read('baseline'), b=await read('candidate');
const strict=compareAcceptance(a.plan.manifest,b.plan.manifest,[a.result.record],[b.result.record]);
const output={strict,nativeModelOutputsEqual:canonicalJson(a.result.receipt.modelOutputs)===canonicalJson(b.result.receipt.modelOutputs),baselineSemantic:a.result.raw.verification.semantic,candidateSemantic:b.result.raw.verification.semantic};
if(await Bun.file(`${root}/comparison.json`).exists())throw Error('Existing comparison refused');
await Bun.write(`${root}/comparison.json`,JSON.stringify(output,null,2));console.log(JSON.stringify(output));
