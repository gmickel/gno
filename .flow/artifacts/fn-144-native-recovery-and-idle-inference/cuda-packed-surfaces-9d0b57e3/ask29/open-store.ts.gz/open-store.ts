import {join} from 'node:path';
const [source,db,configFile]=process.argv.slice(2);
Bun.spawn=()=>{throw Error('GPU/native child forbidden in store preflight');};
Bun.spawnSync=()=>{throw Error('Child process forbidden in store preflight');};
globalThis.fetch=()=>{throw Error('Network forbidden in store preflight');};
const config=await Bun.file(configFile!).json();
const {SqliteAdapter}=await import(join(source!,'src/store/sqlite/adapter.ts'));
const store=new SqliteAdapter();
try {
 const open=await store.open(db,config.ftsTokenizer,config.busyTimeoutMs);
 if(!open.ok)throw Error(JSON.stringify(open.error));
 for(const result of [await store.syncCollections(config.collections),await store.syncContexts(config.contexts??[])])if(!result.ok)throw Error(JSON.stringify(result.error));
 console.log(JSON.stringify({source,db,open,nativeExecution:false}));
}finally{await store.close();}
