import {join} from 'node:path';
const [mode,role]=process.argv.slice(2);if(!['--preflight','--native'].includes(mode??'')||!['baseline','candidate'].includes(role??''))throw Error('run.ts --preflight|--native baseline|candidate');
const root=import.meta.dir;const plan=await Bun.file(join(root,role!,'plan.json')).json();
const harness=join(root,'../package/evals/acceptance');
const {installSessionHarness,createSessionDriverFactory}=await import(join(harness,'session-driver.ts'));
await installSessionHarness(plan.sourceRoot);
if(mode==='--preflight'){console.log(JSON.stringify({role,installed:true,nativeExecution:false}));process.exit(0);}
const out=join(root,role!,'evidence','result.json.gz');if(await Bun.file(out).exists())throw Error('Existing native observation refused');
const {OwnedResources}=await import(join(harness,'resources.ts'));const scope=new OwnedResources(true);let session:any;let result:any;
const at=performance.now();
try {
 session=await createSessionDriverFactory(plan).open(scope);scope.start(100);
 const snapshot=Bun.spawn([process.execPath,'--no-env-file',join(root,'snapshot.ts'),plan.sourceRoot,plan.init.dbPath],{stdout:'pipe',stderr:'pipe'});
 const snap=await new Response(snapshot.stdout).text();const error=await new Response(snapshot.stderr).text();if(await snapshot.exited!==0)throw Error(error);
 await Bun.write(join(root,role!,'actual-client-open-logical.json'),snap);
 const expected=await Bun.file(join(root,role!,'preflight.json')).json();if(!Bun.deepEquals(JSON.parse(snap),expected.afterSdk))throw Error('Logical state changed when actual SDK opened');
 await session.run(plan.requests[0].caseId);
 const reply=JSON.parse(new TextDecoder().decode(Bun.gunzipSync(await Bun.file(join(session.processIdentity.directory,'1.reply.json.gz')).bytes())));
 result=reply.response.result;await Bun.write(out,Bun.gzipSync(JSON.stringify(result)));
}finally {
 await scope.stopSampling();try{await session?.close();}finally{await scope.close();}
 const semantic=result?.raw?.verification?.semantic;
 const generationInputs=result?.receipt?.modelInputs?.filter((input:any)=>input.role==='generation'&&Array.isArray(input.input)&&typeof input.input[0]==='string'&&input.input[0].startsWith("You are GNO's closed-evidence claim verifier."))??[];
 const passed=result?.coverage==='complete'&&semantic?.status==='completed'&&semantic.modelCalls>=1&&generationInputs.length>=1&&!scope.errors.length;
 await Bun.write(join(root,role!,'evidence','receipt.json'),JSON.stringify({role,passed,manifest:plan.manifest,semantic,actualJudgeCalls:generationInputs.length,processIdentity:session?.processIdentity,samples:scope.samples,nativeChildren:scope.descendantEvents,errors:scope.errors,wholeDurationMs:performance.now()-at,coverage:result?.coverage,reasons:result?.reasons},null,2));
 console.log(JSON.stringify({role,passed,coverage:result?.coverage,semantic,actualJudgeCalls:generationInputs.length}));if(!passed)process.exitCode=2;
}
