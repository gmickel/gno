/** Cross-surface field equality, not a forged same-surface fn143 manifest verdict. */
import { join } from "node:path";
const plan = await Bun.file(process.argv[2]!).json();
const { canonicalJson } = await import(
  join(plan.plans.sdk.sourceRoot, "evals/agentic/canonical.ts")
);
const rows = [];
const externalSdk = process.argv[3];
if (externalSdk) {
  const decoded = JSON.parse(
    new TextDecoder().decode(
      Bun.gunzipSync(await Bun.file(externalSdk).bytes())
    )
  );
  const result = decoded.response?.result ?? decoded;
  if (!result.record || !result.receipt || !result.raw)
    throw Error("Reference must contain the full actual SDK result");
  rows.push({
    mode: "sdk",
    result,
    receipt: { passed: result.coverage === "complete" },
  });
}
for (const mode of externalSdk
  ? ["cli", "stdio", "http", "api"]
  : ["sdk", "cli", "stdio", "http", "api"]) {
  const root = join(plan.plans[mode].root, "evidence");
  const result = JSON.parse(
    new TextDecoder().decode(
      Bun.gunzipSync(await Bun.file(join(root, "result.json.gz")).bytes())
    )
  );
  const receipt = await Bun.file(join(root, "receipt.json")).json();
  rows.push({ mode, result, receipt });
}
const reference = rows[0];
const comparisons = [];
for (const row of rows.slice(1)) {
  const checks: Record<string, boolean> = {};
  for (const field of ["results", "citations", "modelInputs", "semanticState"])
    checks[`record.${field}`] =
      canonicalJson(reference.result.record.deterministic[field]) ===
      canonicalJson(row.result.record.deterministic[field]);
  checks["native.modelOutputs"] =
    canonicalJson(reference.result.receipt.modelOutputs) ===
    canonicalJson(row.result.receipt.modelOutputs);
  checks["public.results"] =
    canonicalJson(reference.result.raw.results) ===
    canonicalJson(row.result.raw.results);
  comparisons.push({ reference: "sdk", candidate: row.mode, checks });
}
const passed =
  rows.every((row) => row.receipt.passed) &&
  comparisons.every((row) => Object.values(row.checks).every(Boolean));
const path = join(plan.root, "cross-surface-comparison.json");
if (await Bun.file(path).exists()) throw Error("Existing comparison refused");
await Bun.write(
  path,
  JSON.stringify(
    {
      passed,
      externalSdkReference: externalSdk ?? null,
      phase:
        "Each public surface is a single cold process; external SDK phase comes from its retained session receipt. Exact equality is checked across those stated phases, never used to compare latency.",
      comparisonContract:
        "Full results/citations/model-inputs/semantic-state, all native outputs and complete public results; scope.surface differs by definition and is retained, never rewritten; no fn143 same-surface comparator verdict claimed",
      comparisons,
    },
    null,
    2
  )
);
console.log(JSON.stringify({ passed, path }));
if (!passed) process.exitCode = 2;
