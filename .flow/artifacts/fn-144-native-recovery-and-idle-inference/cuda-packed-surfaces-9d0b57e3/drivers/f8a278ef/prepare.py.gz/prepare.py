#!/usr/bin/env python3
"""CPU-only isolated copies; unchanged original fixture/model/query semantics."""
import argparse,hashlib,json,pathlib,shutil,sqlite3,tarfile
p=argparse.ArgumentParser()
for key in ['root','seed','package','helpers','dependencies']:p.add_argument('--'+key,required=True)
p.add_argument('--shared-corpus')
p.add_argument('--product-commit',required=True)
a=p.parse_args();root=pathlib.Path(a.root).resolve();seed=pathlib.Path(a.seed).resolve()
root.mkdir(mode=0o700) # Never overwrite an existing preparation/run.
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
write=lambda p,x:pathlib.Path(p).write_text(json.dumps(x,indent=2)+'\n')
assert sha(a.package)=='1a01daff5030dfbab0492d8d7d76a759e699a3effbd87ede8a40a290e6879342'
expected=json.loads((pathlib.Path(__file__).parent/'overlay-pin.json').read_text())
assert sha(a.helpers)==expected['sha256'], 'Frozen helper archive mismatch'
with tarfile.open(a.package) as t:t.extractall(root,filter='data')
source=root/'package';product={str(f.relative_to(source)):sha(f) for f in source.rglob('*') if f.is_file()}
with tarfile.open(a.helpers) as t:t.extractall(source,filter='data')
assert all(sha(source/f)==h for f,h in product.items()),'Overlay changed product'
helpers={str(f.relative_to(source)):sha(f) for f in source.rglob('*') if f.is_file() and str(f.relative_to(source)) not in product}
(source/'node_modules').symlink_to(pathlib.Path(a.dependencies).resolve(),target_is_directory=True)
setup=json.loads((seed/'setup.json').read_text());config=setup['config'];request=setup['request'];manifest=setup['manifest']
assert request['query']=='what retry budget did we decide and why' and request['options']=={'limit':5}
assert request['operation']=='hybrid' and config['models']['warmModelTtl']==300000
corpus=pathlib.Path(a.shared_corpus).resolve() if a.shared_corpus else root/'corpus'
if not a.shared_corpus:shutil.copytree(seed/'corpus',corpus)
isolation=corpus.parent if a.shared_corpus else root
assert root.is_relative_to(isolation), 'With shared corpus, root must be inside its parent isolation directory'
shutil.copyfile(seed/'fixtures.json',root/'fixtures.json')
fixtures=json.loads((root/'fixtures.json').read_text())
for f in fixtures:assert sha(corpus/f['path'])==f['sha256'],f['path']
assert sha(root/'fixtures.json')==manifest['fixtures'][0]['sha256']
for model in manifest['models']:assert sha(model['id'].removeprefix('file:'))==model['sha256']
for col in config['collections']:col['path']=str(corpus/col['name'])
# Preserve cache state, model URIs, defaults, corpus bytes, tokenizer, and retrieval inputs.
plans={}
for mode in ['sdk','cli','stdio','http','api']:
 out=root/mode
 for sub in ['data','cache','config','protocol']:(out/sub).mkdir(parents=True)
 with sqlite3.connect('file:'+str(seed/'data/index-default.sqlite')+'?mode=ro',uri=True) as src,sqlite3.connect(out/'data/index-default.sqlite') as dst:src.backup(dst)
 if (seed/'cache').exists():shutil.copytree(seed/'cache',out/'cache',dirs_exist_ok=True)
 write(out/'config/index.yml',config)
 m=json.loads(json.dumps(manifest));assert len(a.product_commit)==40 and all(c in '0123456789abcdef' for c in a.product_commit);m['identity']['commit']=a.product_commit;m['identity']['indexId']='original143-packed-'+mode;m['identity']['indexSha256']=sha(out/'data/index-default.sqlite')
 surface='sdk' if mode=='sdk' else 'cli' if mode=='cli' else 'api' if mode=='api' else 'mcp'
 operation='hybrid'
 case={'caseId':'original143-'+mode,'fixtureSha256':m['cases'][0]['fixtureSha256'],'surface':surface,'preset':m['cases'][0]['preset'],'configuration':{'query':request['query'],'operation':operation,'options':request['options'],'warmModelTtl':300000}}
 if surface=='mcp':case['configuration']['mcpTransport']='http' if mode=='http' else 'stdio'
 m['cases']=[case]
 r={**request,'caseId':case['caseId'],'operation':operation,'manifest':m}
 plans[mode]={'root':str(out),'sourceRoot':str(source),'isolatedRoot':str(isolation),'protocolRoot':str(out/'protocol'),'manifest':m,'init':{'config':config,'dbPath':str(out/'data/index-default.sqlite'),'cacheDir':str(out/'cache')},'requests':[r],'timeoutMs':120000,**({'cudaPath':'/opt/cuda'} if request['expectedBackend']=='cuda' else {})}
 write(out/'manifest.json',m)
write(root/'plan.json',{'root':str(root),'corpusRoot':str(corpus),'isolatedRoot':str(isolation),'plans':plans,'seed':str(seed),'helperCommit':'f8a278ef','nativeExecution':False})
write(root/'provenance.json',{'packageSha256':sha(a.package),'overlaySha256':sha(a.helpers),'productFiles':product,'helperFiles':helpers,'seedSetupSha256':sha(seed/'setup.json'),'fixtureSha256':sha(root/'fixtures.json'),'fixtureFiles':len(fixtures),'models':manifest['models'],'changes':['corpus/config/data/cache paths relocated to isolated copies','surface/case identity explicit per entry'],'cachePolicy':'initial DB and cache copied without deleting or priming','nativeExecution':False})
print(root/'plan.json')
