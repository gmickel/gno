import pathlib,json,gzip,hashlib,shutil
base=pathlib.Path('/home/gordon/.cache/agent-tmp'); repo=pathlib.Path('/home/gordon/work/gno'); dest=repo/'.flow/artifacts/fn-144-native-recovery-and-idle-inference/cuda-packed-surfaces-9d0b57e3';dest.mkdir(exist_ok=False)
old=base/'gno-fn144-packed-surfaces-98252a9c';new=base/'gno-fn144-packed-surfaces-f8a278ef';public=base/'gno-fn144-burst-preparation/original143';ask=old/'ask29'
manifest=[]
def copy(src,rel):
 if not src.is_file():return
 raw=src.read_bytes();out=dest/rel
 if out.suffix!='.gz':out=out.with_name(out.name+'.gz');data=gzip.compress(raw,mtime=0)
 else:data=raw
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);manifest.append({'path':str(out.relative_to(dest)),'source':str(src),'sourceSha256':hashlib.sha256(raw).hexdigest(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
for mode in ['cli','stdio','http','api']:
 root=public/('public-surfaces-98252a9c' if mode in ['cli','stdio'] else 'public-surfaces-f8a278ef')
 for p in (root/mode/'evidence').rglob('*'):
  if p.is_file():copy(p,pathlib.Path('surfaces')/mode/'evidence'/p.relative_to(root/mode/'evidence'))
 for n in ['manifest.json','config/index.yml']:copy(root/mode/n,pathlib.Path('surfaces')/mode/n)
for suffix in ['98252a9c','f8a278ef']:
 root=public/f'public-surfaces-{suffix}'
 for n in ['plan.json','provenance.json','fixtures.json']:copy(root/n,pathlib.Path('provenance')/suffix/n)
for role in ['baseline','candidate']:
 for directory in ['evidence','protocol']:
  for p in (ask/role/directory).rglob('*'):
   if p.is_file():copy(p,pathlib.Path('ask29')/role/directory/p.relative_to(ask/role/directory))
 for p in (ask/role).iterdir():
  if p.is_file():copy(p,pathlib.Path('ask29')/role/p.name)
for p in ask.iterdir():
 if p.is_file():copy(p,pathlib.Path('ask29')/p.name)
for n in ['sdk-first.json.gz','sdk-reference.json','prepare.py','drive.ts']:copy(old/n,pathlib.Path('drivers/98252a9c')/n)
for n in ['prepare.py','drive.ts','compare-surfaces.ts','comparison-plan.json','cross-surface-comparison.json','cleanup.json','overlay-pin.json','archive.py']:copy(new/n,pathlib.Path('drivers/f8a278ef')/n)
for root in [old,new]:
 for p in root.glob('cuda-*'):
  if p.is_file():copy(p,pathlib.Path('supervisors')/root.name/p.name)
for n in ['snapshot.json','setup.json','fixtures.json']:copy(base/'gno-fn144-packed-surfaces-9244d715/cuda-seed'/n,pathlib.Path('seed')/n)
(dest/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'root':str(dest),'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest)}))
