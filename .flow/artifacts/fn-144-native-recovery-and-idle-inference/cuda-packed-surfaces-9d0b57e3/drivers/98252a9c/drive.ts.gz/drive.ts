/** Thin runner over the frozen acceptance adapters; no private model implementation. */
import { mkdir } from "node:fs/promises";
import { join } from "node:path";
const [flag, planPath, mode] = process.argv.slice(2);
if (!["--validate", "--native"].includes(flag ?? "") || !planPath)
  throw Error("drive.ts --validate|--native PLAN [sdk|cli|stdio|http|api]");
const plan = await Bun.file(planPath).json();
const source = plan.plans.sdk.sourceRoot;
if (flag === "--native" && !plan.nativeExecutionDisabled) {
  const pins = await Bun.file(join(plan.root, "provenance.json")).json();
  for (const [file, expected] of Object.entries({
    ...pins.productFiles,
    ...pins.helperFiles,
  })) {
    const actual = new Bun.CryptoHasher("sha256")
      .update(await Bun.file(join(source, file)).bytes())
      .digest("hex");
    if (actual !== expected)
      throw Error(`Frozen package/helper changed: ${file}`);
  }
}
const { acceptanceManifestSchema } = await import(
  join(source, "evals/acceptance/manifest.ts")
);
for (const settings of Object.values(plan.plans) as any[]) {
  acceptanceManifestSchema.parse(settings.manifest);
  const request = settings.requests[0];
  if (
    request.query !== "what retry budget did we decide and why" ||
    JSON.stringify(request.options) !== '{"limit":5}' ||
    request.operation !== "hybrid"
  )
    throw Error("Original143 request changed");
}
if (flag === "--native" && plan.nativeExecutionDisabled)
  throw Error("Validation-only template has no runnable seed index");
if (flag === "--validate") {
  console.log(
    JSON.stringify({
      valid: true,
      nativeExecution: false,
      modes: Object.keys(plan.plans),
    })
  );
  process.exit(0);
}
if (!["sdk", "cli", "stdio", "http", "api"].includes(mode ?? ""))
  throw Error("Explicit supported surface required");
const settings = plan.plans[mode!],
  request = settings.requests[0],
  out = join(settings.root, "evidence");
await mkdir(out, { mode: 0o700 }); // Never overwrite a run.
const at = performance.now();
let result: any;
if (mode === "sdk") {
  const { createSessionDriverFactory } = await import(
    join(source, "evals/acceptance/session-driver.ts")
  );
  const { OwnedResources } = await import(
    join(source, "evals/acceptance/resources.ts")
  );
  const resources = new OwnedResources(request.expectedBackend === "cuda");
  let session: any;
  try {
    session = await createSessionDriverFactory(settings).open(resources);
    resources.start(100);
    await session.run(request.caseId);
    // run() intentionally returns projection only. Preserve the complete IPC response.
    const path = join(session.processIdentity.directory, "1.reply.json.gz");
    const reply = JSON.parse(
      new TextDecoder().decode(Bun.gunzipSync(await Bun.file(path).bytes()))
    );
    result = reply.response.result;
  } finally {
    await resources.stopSampling();
    try {
      await session?.close();
    } finally {
      await resources.close();
    }
    await Bun.write(
      join(out, "resources.json"),
      JSON.stringify(
        {
          processIdentity: session?.processIdentity,
          samples: resources.samples,
          nativeChildren: resources.descendantEvents,
          errors: resources.errors,
        },
        null,
        2
      )
    );
    if (resources.errors.length) process.exitCode = 2;
  }
} else {
  const { runSurfaceAcceptance } = await import(
    join(source, "evals/acceptance/surface-adapter.ts")
  );
  const env: Record<string, string> = {
    GNO_CONFIG_DIR: join(settings.root, "config"),
    GNO_DATA_DIR: join(settings.root, "data"),
    GNO_CACHE_DIR: join(settings.root, "cache"),
  };
  if (request.expectedBackend === "cuda") env.CUDA_PATH = "/opt/cuda";
  const entry = join(source, "src/index.ts");
  const config = join(settings.root, "config/index.yml");
  let args: string[], invocation: any;
  if (mode === "cli") {
    args = [
      entry,
      "--config",
      config,
      "query",
      request.query,
      "-n",
      "5",
      "--explain",
      "--json",
    ];
    invocation = { surface: "cli" };
  } else if (mode === "stdio") {
    args = [entry, "--config", config, "mcp"];
    invocation = {
      surface: "mcp",
      transport: "stdio",
      tool: "gno_query",
      arguments: { query: request.query, limit: 5, explain: true },
    };
  } else {
    const reserved = Bun.serve({
      hostname: "127.0.0.1",
      port: 0,
      fetch: () => new Response("reserved"),
    });
    const port = reserved.port;
    await reserved.stop(true);
    args = [
      entry,
      "--config",
      config,
      "serve",
      "--host",
      "127.0.0.1",
      "--port",
      String(port),
    ];
    invocation =
      mode === "http"
        ? {
            surface: "mcp",
            transport: "http",
            url: `http://127.0.0.1:${port}/mcp`,
            tool: "gno_query",
            arguments: { query: request.query, limit: 5, explain: true },
          }
        : {
            surface: "api",
            url: `http://127.0.0.1:${port}/api/query`,
            body: { query: request.query, limit: 5, explain: true },
          };
  }
  await Bun.write(
    join(out, "invocation.json"),
    JSON.stringify({ args, invocation, env }, null, 2)
  );
  result = await runSurfaceAcceptance(
    request,
    {
      args,
      cwd: source,
      env,
      isolatedRoot: plan.isolatedRoot ?? plan.root,
      capturePath: join(out, "capture.json"),
      timeoutMs: 120000,
    },
    invocation,
    async (uri: string) => {
      const path = join(
        plan.corpusRoot ?? join(plan.root, "corpus"),
        decodeURIComponent(uri.replace(/^gno:\/\//, ""))
      );
      const content = await Bun.file(path).text();
      return {
        content,
        sourceHash: new Bun.CryptoHasher("sha256")
          .update(content)
          .digest("hex"),
      };
    }
  );
}
await Bun.write(
  join(out, "result.json.gz"),
  Bun.gzipSync(JSON.stringify(result))
);
const preset = settings.init.config.models.presets.find(
  (x: any) => x.id === settings.init.config.models.activePreset
);
const required = [preset.embed, preset.rerank, preset.expand];
const exercised = required.map((modelId: string) => ({
  modelId,
  seen: result.receipt.modelInputs.some((x: any) => x.modelId === modelId),
}));
const nativeRequests = result.receipt.nativeRequests ?? [];
const parent = result.receipt.parentNative;
const passed =
  result.coverage === "complete" &&
  exercised.every((x: any) => x.seen) &&
  nativeRequests.length > 0 &&
  nativeRequests.every((x: any) => x.complete) &&
  parent &&
  parent.bindingLoads.length === 0 &&
  (parent.mappedModels === null || parent.mappedModels.length === 0);
await Bun.write(
  join(out, "receipt.json"),
  JSON.stringify(
    {
      passed,
      mode,
      manifest: settings.manifest,
      exercised,
      nativeRequests: nativeRequests.length,
      coverage: result.coverage,
      reasons: result.reasons,
      wholeDurationMs: performance.now() - at,
    },
    null,
    2
  )
);
console.log(JSON.stringify({ passed, mode, out }));
if (!passed) process.exitCode = 2;
